#include "plat_rf.h"

#define RF_PIN_LEVEL()      GPIO_ReadPin(CW_GPIOB, GPIO_PIN_0) // �������� PB00

/* �㷨��ֵ (���� 60us) */
#define TICKS_SYNC_MIN      60    // ͬ��ͷ3.6ms
#define TICKS_MAX_LIMIT     450   // 27ms ��ʱ�ж�
#define TICKS_GLITCH        2     // ë�̹���

RF_Msg_t g_rf_msg = {0};

void RF433_Handler_60us(void) {
    static uint8_t  state = 0; 	// 0:Idle, 1:Receiving
    static uint32_t h_ticks = 0, l_ticks = 0, rx_reg = 0;
    static uint8_t  bit_cnt = 0, last_pin = 1;

    uint8_t cur_pin = RF_PIN_LEVEL();
    if (cur_pin) h_ticks++; else l_ticks++;

    if (cur_pin != last_pin) {
        if (cur_pin == 1) { 	// �½��ؽ��� (Low����)
            if (state == 0) {
                if (l_ticks > TICKS_SYNC_MIN && l_ticks < TICKS_MAX_LIMIT) {
                    state = 1; bit_cnt = 0; rx_reg = 0;
                }
            } else {
                rx_reg <<= 1;
                if (h_ticks > l_ticks) rx_reg |= 1; // ����Ӧ�����㷨����
                if (++bit_cnt == 24) {
                    g_rf_msg.addr = (rx_reg >> 8) & 0xFFFF;
                    g_rf_msg.key  = rx_reg & 0xFF;
                    g_rf_msg.type = RF_TYPE_24BIT;
					g_rf_msg.vld  = true;			// 24λЭ���յ���������ǣ���ֹ�ȴ���ʱ�����ӳ�
                } else if (bit_cnt == 32) {
                    uint8_t sum = (uint8_t)((rx_reg>>24) + (rx_reg>>16) + (rx_reg>>8));
                    if (sum == (uint8_t)(rx_reg & 0xFF)) {
                        g_rf_msg.addr = (rx_reg >> 16) & 0xFFFF;
                        g_rf_msg.key  = (rx_reg >> 8) & 0xFF;
                        g_rf_msg.type = RF_TYPE_32BIT;
                        g_rf_msg.vld = true;
                    }
                    state = 0;
                }
            }
            h_ticks = 0;
        } else { // �����ؽ��� (High����) 
            if (h_ticks > TICKS_MAX_LIMIT) state = 0;
            l_ticks = 0;
        }
        last_pin = cur_pin;
    }

    // ��ʱ����
    if (l_ticks > TICKS_MAX_LIMIT || h_ticks > TICKS_MAX_LIMIT) {
        state = 0; l_ticks = 0; h_ticks = 0;
    }
}



