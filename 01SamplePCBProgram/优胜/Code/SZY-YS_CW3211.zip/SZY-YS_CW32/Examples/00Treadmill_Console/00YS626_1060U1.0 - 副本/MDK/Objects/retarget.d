./objects/retarget.o: ..\..\..\..\Utilities\retarget.c \
  D:\Software\Keil_V5\MDK\ARM\ARMCLANG\Bin\..\include\stdio.h \
  ..\..\..\..\Libraries\inc\cw32l010.h \
  D:\Software\Keil_V5\MDK\ARM\PACK\ARM\CMSIS\5.8.0\CMSIS\Core\Include\core_cm0plus.h \
  D:\Software\Keil_V5\MDK\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\Software\Keil_V5\MDK\ARM\PACK\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_version.h \
  D:\Software\Keil_V5\MDK\ARM\PACK\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_compiler.h \
  D:\Software\Keil_V5\MDK\ARM\PACK\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_armclang.h
