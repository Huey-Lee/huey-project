./objects/sys_aerobuf.o: ..\SYSTEM\sys_aerobuf.c ..\SYSTEM\sys_aerobuf.h \
  D:\Software\Keil_V5\MDK\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\Software\Keil_V5\MDK\ARM\ARMCLANG\Bin\..\include\stdbool.h
