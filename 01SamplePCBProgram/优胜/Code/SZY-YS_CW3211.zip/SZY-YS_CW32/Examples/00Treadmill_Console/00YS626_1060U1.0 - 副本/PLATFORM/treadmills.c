//#include "treadmills.h"
//#include "ui_display.h"
//#include "plat_segment.h"
//#include "plat_beep.h"
//#include "plat_keyfun.h"
//#include "plat_aerolink.h"

///* ���ò��� */
//#define TM_STOP_TIME_COUNT    50    
//#define SPEED_SYNC_TIMEOUT    60    // �ӳ��� 6�����
//#define MAX_CMD_LEAD          20    // ����ָ�����ȷ���������ֵ��2.0 km/h (20 * 0.1)

///* Ӳ��ָʾ�ƶ��� (GRID4) */
//#define GRID_IND       4   
//#define LED_SPEED      1   // SEG2
//#define LED_TIME       0   // SEG1
//#define LED_DIS        2   // SEG3
//#define LED_CAL        3   // SEG4

//#define GRID_COLON     4   
//#define SEG_COLON_H    5   // SEG6
//#define SEG_COLON_L    4   // SEG5

//TM_Control_t g_TM;

//static uint16_t s_heartbeat_tick = 0; 
//static uint8_t  s_lower_status = 10;   
//static uint16_t s_fbk_speed = 0;       
//static uint16_t s_last_fbk_speed = 0;  
//static uint8_t  s_speed_err_cnt = 0;   
//static uint16_t s_sys_temp = 0;        

///**
// * @brief �·��ٶ�
// */
//static void Send_Speed_To_Lower(void) {
//    uint8_t data[8] = {0};
//    data[0] = (uint8_t)(g_TM.speed >> 8);   
//    data[1] = (uint8_t)(g_TM.speed & 0xFF); 
//    AeroLink_Send(FC_GEAR, 0x00, data);
//}

//static void TM_Trigger_Error(uint16_t err_code) {
//    if (g_TM.state == TM_STATE_ERROR && g_TM.error_code == err_code) return;
//    g_TM.state = TM_STATE_ERROR;
//    g_TM.error_code = err_code;
//    Beep_Play(BEEP_ALARM); 
//    UI_MarkDirty();
//}

//static void Treadmill_Reset_Data(void) {
//    g_TM.time = 0; g_TM.dist = 0.0f; g_TM.cal = 0.0f;
//    g_TM.speed = TM_SPEED_MIN;
//    g_TM.target_mode = TARGET_NONE;
//    g_TM.disp_index = DISP_TIME;
//    g_TM.steady_timer = 0; g_TM.cycle_timer = 0;
//    s_speed_err_cnt = 0; s_fbk_speed = 0; s_last_fbk_speed = 0;
//    UI_ClearAll(); 
//}

//void Treadmill_Init(void) {
//    g_TM.state = TM_STATE_BOOT; g_TM.safety_key = true; Treadmill_Reset_Data(); 
//}

///**
// * @brief �������ڴ��� - ���ĸĽ��������뷴�����ٿ���
// */
//static void TM_Adjust_Process(int8_t dir) {
//    g_TM.steady_timer = 20; 
//    UI_MarkDirty();
//    
//    switch (g_TM.disp_index) {
//        case DISP_SPEED:
//            if (dir > 0) {
//                // ���ؼ��Ż��������Ŀ���ٶȱȷ������� 2.0km/h ���ϣ���ֹ��������Ŀ��ֵ
//                // ���� UI ���ֻ�ȵ��׷���������ӣ����׶ž� E14
//                if (g_TM.speed >= TM_SPEED_MAX) {
//                    Beep_Play(BEEP_LIMIT);
//                } else if (g_TM.state == TM_STATE_RUNNING && (g_TM.speed > s_fbk_speed + MAX_CMD_LEAD)) {
//                    // ���û׷�ϣ�ָ����ӣ����������������־�Ĭ�ȴ�
//                    return; 
//                } else {
//                    g_TM.speed += TM_SPEED_STEP;
//                }
//            } else {
//                if (g_TM.speed <= TM_SPEED_MIN) Beep_Play(BEEP_LIMIT);
//                else g_TM.speed -= TM_SPEED_STEP;
//            }
//            if (g_TM.state == TM_STATE_RUNNING) Send_Speed_To_Lower();
//            break;
//            
//        case DISP_TIME:
//            if (dir > 0) g_TM.time = (g_TM.time >= TM_TIME_MAX) ? TM_TIME_MIN : (g_TM.time + TM_TIME_STEP);
//            else         g_TM.time = (g_TM.time <= TM_TIME_MIN) ? TM_TIME_MAX : (g_TM.time - TM_TIME_STEP);
//            break;
//        case DISP_DIST:
//            if (dir > 0) g_TM.dist = (g_TM.dist >= TM_DIST_MAX) ? TM_DIST_MIN : (g_TM.dist + TM_DIST_STEP);
//            else         g_TM.dist = (g_TM.dist <= TM_DIST_MIN) ? TM_DIST_MAX : (g_TM.dist - TM_DIST_STEP);
//            break;
//        case DISP_CAL:
//            if (dir > 0) g_TM.cal = (g_TM.cal >= TM_CAL_MAX) ? TM_CAL_MIN : (g_TM.cal + TM_CAL_STEP);
//            else         g_TM.cal = (g_TM.cal <= TM_CAL_MIN) ? TM_CAL_MAX : (g_TM.cal - TM_CAL_STEP);
//            break;
//        default: break;
//    }
//}

//void Treadmill_On_Event(uint8_t key_id, uint8_t evt) {
//    if (evt == K_EVT_RELEASE) return;
//    if (g_TM.state == TM_STATE_ERROR) {
//        if (key_id == K_ID_ONOFF && g_TM.safety_key) { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
//        return;
//    }
//    if ((key_id == K_ID_MODE || key_id == K_ID_ONOFF) && evt == K_EVT_HOLD) return;
//    if (g_TM.state == TM_STATE_BOOT) {
//        if (key_id == K_ID_ONOFF || key_id == K_ID_MODE) { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
//        return; 
//    } 
//    switch (g_TM.state) {
//        case TM_STATE_IDLE:
//            if (key_id == K_ID_ONOFF) {
//                Treadmill_Reset_Data(); g_TM.state = TM_STATE_COUNTDOWN; g_TM.timer_100ms = 30; 
//            } else if (key_id == K_ID_MODE) {
//                g_TM.state = TM_STATE_SETTING; g_TM.disp_index = DISP_TIME; g_TM.target_mode = TARGET_TIME; g_TM.time = TM_TIME_SET; 
//            }
//            break;
//        case TM_STATE_SETTING:
//            if (key_id == K_ID_MODE) {
//                if (g_TM.disp_index == DISP_TIME) { g_TM.disp_index = DISP_DIST; g_TM.target_mode = TARGET_DIST; g_TM.dist = TM_DIST_SET; } 
//                else if (g_TM.disp_index == DISP_DIST) { g_TM.disp_index = DISP_CAL; g_TM.target_mode = TARGET_CAL; g_TM.cal = TM_CAL_SET; } 
//                else { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
//            } else if (key_id == K_ID_UP || key_id == K_ID_DN) TM_Adjust_Process(key_id == K_ID_UP ? 1 : -1);
//            else if (key_id == K_ID_ONOFF) { g_TM.state = TM_STATE_COUNTDOWN; g_TM.timer_100ms = 30; }
//            break;
//        case TM_STATE_COUNTDOWN:
//            if (key_id == K_ID_ONOFF) { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
//            break;
//        case TM_STATE_RUNNING: 
//            if (key_id == K_ID_ONOFF) { 
//                g_TM.state = TM_STATE_STOPPING; g_TM.timer_100ms = TM_STOP_TIME_COUNT;
//                AeroLink_Send(FC_CONTROL, 0x01, (void*)0); 
//            } else if (key_id == K_ID_UP || key_id == K_ID_DN) {  
//                g_TM.disp_index = DISP_SPEED; g_TM.cycle_timer = 0; TM_Adjust_Process(key_id == K_ID_UP ? 1 : -1);
//            }                           
//            break;
//        default: break;
//    }
//    UI_MarkDirty(); 
//}

///* UI��Ⱦ����(����ԭ��) */
//static void TM_UI_Dispatcher(void) {
//    if (g_TM.state == TM_STATE_BOOT) {
//        if (g_TM.timer_100ms == 0) Beep_Play(BEEP_CLICK); 
//        if (++g_TM.timer_100ms < 10) { for(uint8_t i=0; i<6; i++) UI_SetRaw(i, 0xFF); } 
//        else if (g_TM.timer_100ms < 25) { 
//            if (g_TM.timer_100ms == 10) UI_ClearAll();
//            UI_SetRaw(0, SEG_RAW(SEG_U)); UI_SetNumber(1, 10, 2, 2, ZERO_SHOW); 
//            UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
//        } 
//        else if (g_TM.timer_100ms < 40) { 
//            if (g_TM.timer_100ms == 25) UI_ClearAll();
//            UI_SetRaw(0, SEG_RAW(SEG_C)); UI_SetNumber(1, 1, 2, 2, ZERO_SHOW); 
//            UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
//        } 
//        else { g_TM.state = TM_STATE_IDLE; g_TM.timer_100ms = 0; }
//        return;
//    }
//    static TM_State_t s_last_state = TM_STATE_BOOT;
//    static TM_DispIndex_t s_last_disp = DISP_SPEED;
//    if (g_TM.state != s_last_state || g_TM.disp_index != s_last_disp) {
//        UI_ClearAll(); s_last_state = g_TM.state; s_last_disp = g_TM.disp_index;
//    }
//    for(uint8_t i=0; i<6; i++) UI_SetBitMode(GRID_IND, i, DISP_OFF); 
//    bool is_blink = (g_TM.state == TM_STATE_SETTING && g_TM.steady_timer == 0);
//    UI_SetBlinkTime(1000);
//    for(uint8_t i=0; i<4; i++) UI_SetGridBlinkMask(i, is_blink);
//    switch (g_TM.state) {
//        case TM_STATE_IDLE:
//            UI_SetNumber(1, 0, 3, 0, ZERO_SHOW); UI_SetBitMode(GRID_IND, LED_TIME, DISP_ON);
//            UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK); UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_BLINK);
//            break;
//        case TM_STATE_COUNTDOWN: {
//            uint8_t cd = (g_TM.timer_100ms + 9) / 10;
//            if (cd < 1) cd = 1; UI_SetNumber(2, cd, 1, 0, ZERO_HIDE); break;
//        }
//        case TM_STATE_STOPPING: 
//        case TM_STATE_SETTING:
//        case TM_STATE_RUNNING:
//            if (g_TM.state == TM_STATE_STOPPING || g_TM.disp_index == DISP_SPEED) {
//                if (g_TM.speed < 10) UI_SetNumber(1, g_TM.speed, 2, 0, ZERO_SHOW); 
//                else UI_SetNumber(0, g_TM.speed, 3, 0, ZERO_HIDE);
//                UI_SetBitMode(GRID_IND, LED_SPEED, DISP_ON); UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
//            } 
//            else if (g_TM.disp_index == DISP_TIME) {
//                uint16_t disp = (g_TM.time / 60) * 100 + (g_TM.time % 60);
//                if (g_TM.time / 60 >= 10) UI_SetNumber(0, disp, 4, 2, ZERO_SHOW); else UI_SetNumber(1, disp, 3, 2, ZERO_SHOW);
//                UI_SetBitMode(GRID_IND, LED_TIME, DISP_ON);
//                UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK); UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_BLINK);
//            } 
//            else if (g_TM.disp_index == DISP_DIST) {
//                UI_SetNumber(0, (uint32_t)(g_TM.dist / 10.0f), 4, 3, ZERO_HIDE);
//                UI_SetBitMode(GRID_IND, LED_DIS, DISP_ON); UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
//            } 
//            else if (g_TM.disp_index == DISP_CAL) {
//                UI_SetNumber(0, (uint32_t)(g_TM.cal / 1000.0f), 4, 0, ZERO_HIDE); UI_SetBitMode(GRID_IND, LED_CAL, DISP_ON);
//            }
//            break;
//        case TM_STATE_ERROR: 
//            UI_SetRaw(0, SEG_RAW(SEG_E)); UI_SetNumber(1, g_TM.error_code, 2, 0, ZERO_SHOW); UI_SetRaw(3, 0); break;
//        default: break;     
//    }
//}

///**
// * @brief ���ճ���
// */
//void AeroLink_OnFrameReceived(AeroFrame_t *f) {
//    if (f->fc == 0x01) {
//        if (f->sfc == 0x00) { 
//            s_fbk_speed = f->data[1]; 
//            s_lower_status = f->data[3]; 
//            if ((s_lower_status == 10 || s_lower_status == 7) && (g_TM.state == TM_STATE_RUNNING || g_TM.state == TM_STATE_STOPPING)) {
//                g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data();
//            }
//            UI_MarkDirty();
//        } 
//        else if (f->sfc == 0x01) { 
//            uint16_t err_raw = (uint16_t)((f->data[0] << 8) | f->data[1]);
//            uint8_t  err_sub = f->data[3];
//            if (err_raw || err_sub) {
//                uint16_t code = 0;
//                if (err_raw) { for (uint8_t i=0; i<13; i++) { if (err_raw & (1<<i)) { code = i+1; break; } } }
//                else if (err_sub) { if (err_sub & 0x01) code = 14; else if (err_sub & 0x02) code = 15; }
//                if (code) TM_Trigger_Error(code);
//            }
//        }
//    } else if (f->fc == 0x02 && f->sfc == 0x00) {
//        s_sys_temp = (uint16_t)((((uint16_t)f->data[4] << 8) | f->data[5]) >> 1);
//    }
//}

///**
// * @brief 100ms �������
// */
//void Treadmill_Manager_100ms(void) {
//    static float s_accum_dist = 0.0f;
//    static uint16_t s_stop_start_speed = 0;
//    static uint8_t s_sync_check_tick = 0;

//    if (++s_heartbeat_tick >= 5) { s_heartbeat_tick = 0; AeroLink_Send(FC_HEARTBEAT, 0x00, (void*)0); }
//    if (g_TM.state == TM_STATE_ERROR) { TM_UI_Dispatcher(); return; }
//    if (g_TM.steady_timer > 0 && --g_TM.steady_timer == 0) UI_MarkDirty();

//    if (g_TM.state == TM_STATE_COUNTDOWN) {
//        if (g_TM.timer_100ms > 0) {
//            if (g_TM.timer_100ms % 10 == 0) Beep_Play(BEEP_CLICK);
//            g_TM.timer_100ms--;
//        } else {
//            g_TM.state = TM_STATE_RUNNING; s_accum_dist = 0.0f;
//            AeroLink_Send(FC_CONTROL, 0x00, (void*)0); Send_Speed_To_Lower(); 
//        }
//    }

//    if (g_TM.state == TM_STATE_RUNNING) {
//        // ÿ�벹��һ��ָ�ȷ��ͨѶ��׳
//        if (++s_sync_check_tick >= 10) { 
//            s_sync_check_tick = 0;
//            if (s_lower_status != 9) AeroLink_Send(FC_CONTROL, 0x00, (void*)0);
//            Send_Speed_To_Lower(); 
//        }

//        // --- ����У���߼����ſ������� ---
//        int16_t diff = (int16_t)g_TM.speed - (int16_t)s_fbk_speed;
//        if (diff < 0) diff = -diff;

//        if (diff > 5) { // ���� 0.5km/h 
//            if (s_fbk_speed != s_last_fbk_speed) { 
//                s_speed_err_cnt = 0; // ֻҪ����ڶ�������û׷�ϣ�Ҳ������
//            } else {
//                if (++s_speed_err_cnt >= SPEED_SYNC_TIMEOUT) { TM_Trigger_Error(14); return; }
//            }
//        } else { s_speed_err_cnt = 0; }
//        s_last_fbk_speed = s_fbk_speed;

//        // �˶�����
//        static uint8_t sec_cnt = 0;
//        if (++sec_cnt >= 10) {
//            sec_cnt = 0;
//            float inc = (float)g_TM.speed / 36.0f; s_accum_dist += inc;
//            bool stop_flag = false;
//            if (g_TM.target_mode == TARGET_TIME) { if(g_TM.time > 0) g_TM.time--; else stop_flag = true; }
//            else { g_TM.time++; if(g_TM.time >= TM_TIME_MAX) stop_flag = true; }
//            if (g_TM.target_mode == TARGET_DIST) { g_TM.dist -= inc; if(g_TM.dist <= 0) stop_flag = true; } else g_TM.dist = s_accum_dist;
//            if (g_TM.target_mode == TARGET_CAL) { g_TM.cal -= inc*0.06f; if(g_TM.cal <= 0) stop_flag = true; } else g_TM.cal = s_accum_dist*0.06f;
//            if (stop_flag) { g_TM.state = TM_STATE_STOPPING; g_TM.timer_100ms = TM_STOP_TIME_COUNT; AeroLink_Send(FC_CONTROL, 0x01, (void*)0); }
//        }
//        if (g_TM.steady_timer == 0 && ++g_TM.cycle_timer >= 50) {
//            g_TM.cycle_timer = 0; g_TM.disp_index = (TM_DispIndex_t)((g_TM.disp_index + 1) % 4);
//        }
//    }

//    if (g_TM.state == TM_STATE_STOPPING) {
//        static uint8_t stop_retry = 0;
//        if (++stop_retry >= 10) { stop_retry = 0; if (s_lower_status != 10 && s_lower_status != 7) AeroLink_Send(FC_CONTROL, 0x01, (void*)0); }
//        if (g_TM.timer_100ms == TM_STOP_TIME_COUNT) s_stop_start_speed = g_TM.speed;
//        if (g_TM.timer_100ms > 0) {
//            g_TM.timer_100ms--;
//            g_TM.speed = (uint32_t)s_stop_start_speed * g_TM.timer_100ms / TM_STOP_TIME_COUNT;
//        } else {
//            g_TM.speed = 0; g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data();
//        }
//        UI_MarkDirty();
//    }
//    TM_UI_Dispatcher();
//}


////#include "treadmills.h"
////#include "ui_display.h"
////#include "plat_segment.h"
////#include "plat_beep.h"
////#include "plat_keyfun.h"
////#include "plat_aerolink.h"

/////* ���ò��� */
////#define TM_STOP_TIME_COUNT    50    // ֹͣ����ʱ�䣺5��
////#define SPEED_SYNC_TIMEOUT    50    // �ٶ�ͬ����ʱ���ӵ� 5��
////#define SPEED_TOLERANCE       2     // �ݲ� 0.2km/h

/////* Ӳ��ָʾ�ƶ��� (GRID4) */
////#define GRID_IND       4   
////#define LED_SPEED      1   // SEG2
////#define LED_TIME       0   // SEG1
////#define LED_DIS        2   // SEG3
////#define LED_CAL        3   // SEG4

////#define GRID_COLON     4   
////#define SEG_COLON_H    5   // SEG6
////#define SEG_COLON_L    4   // SEG5

////TM_Control_t g_TM;

////// ��̬ͨѶ��ر���
////static uint16_t s_heartbeat_tick = 0; 
////static uint8_t  s_lower_status = 10;   // 0:��ʼ, 7:�ȴ�, 9:����, 10:ֹͣ
////static uint16_t s_fbk_speed = 0;       // �¿ط�����ʵ�ٶ�
////static uint16_t s_last_fbk_speed = 0;  // ��һ�η����ٶ�
////static uint8_t  s_speed_err_cnt = 0;   // �ٶ�ͬ���������
////static uint16_t s_sys_temp = 0;        // �¿�ϵͳ�¶�

/////**
//// * @brief �����������·��ٶ�
//// */
////static void Send_Speed_To_Lower(void) {
////    uint8_t data[8] = {0};
////    data[0] = (uint8_t)(g_TM.speed >> 8);   
////    data[1] = (uint8_t)(g_TM.speed & 0xFF); 
////    AeroLink_Send(FC_GEAR, 0x00, data);
////}

/////**
//// * @brief ����ʽ���ϴ�����
//// */
////static void TM_Trigger_Error(uint16_t err_code) {
////    if (g_TM.state == TM_STATE_ERROR && g_TM.error_code == err_code) return;
////    g_TM.state = TM_STATE_ERROR;
////    g_TM.error_code = err_code;
////    Beep_Play(BEEP_ALARM); 
////    UI_MarkDirty();
////}

/////**
//// * @brief �����˶�����
//// */
////static void Treadmill_Reset_Data(void) {
////    g_TM.time	  = 0;
////    g_TM.dist     = 0.0f;
////    g_TM.cal      = 0.0f;
////    g_TM.speed    = TM_SPEED_MIN;
////    g_TM.target_mode  = TARGET_NONE;
////    g_TM.disp_index   = DISP_TIME;
////    g_TM.steady_timer = 0;
////    g_TM.cycle_timer  = 0;
////    s_speed_err_cnt   = 0;
////    s_fbk_speed       = 0;
////    s_last_fbk_speed  = 0;
////    UI_ClearAll(); 
////}

/////**
//// * @brief ϵͳ��ʼ��
//// */
////void Treadmill_Init(void) {
////    g_TM.state = TM_STATE_BOOT; 
////    g_TM.safety_key = true; 
////    Treadmill_Reset_Data(); 
////}

/////**
//// * @brief �������ڴ��� (�Ӽ���)
//// */
////static void TM_Adjust_Process(int8_t dir) {
////    g_TM.steady_timer = 20; 
////    UI_MarkDirty();
////    bool is_limit = false;
////    switch (g_TM.disp_index) {
////        case DISP_SPEED:
////            if (dir > 0) {
////                if (g_TM.speed >= TM_SPEED_MAX) is_limit = true;
////                else g_TM.speed += TM_SPEED_STEP;
////            } else {
////                if (g_TM.speed <= TM_SPEED_MIN) is_limit = true;
////                else g_TM.speed -= TM_SPEED_STEP;
////            }
////            if (g_TM.state == TM_STATE_RUNNING) Send_Speed_To_Lower();
////            break;
////        case DISP_TIME:
////            if (dir > 0) g_TM.time = (g_TM.time >= TM_TIME_MAX) ? TM_TIME_MIN : (g_TM.time + TM_TIME_STEP);
////            else         g_TM.time = (g_TM.time <= TM_TIME_MIN) ? TM_TIME_MAX : (g_TM.time - TM_TIME_STEP);
////            break;
////        case DISP_DIST:
////            if (dir > 0) g_TM.dist = (g_TM.dist >= TM_DIST_MAX) ? TM_DIST_MIN : (g_TM.dist + TM_DIST_STEP);
////            else         g_TM.dist = (g_TM.dist <= TM_DIST_MIN) ? TM_DIST_MAX : (g_TM.dist - TM_DIST_STEP);
////            break;
////        case DISP_CAL:
////            if (dir > 0) g_TM.cal = (g_TM.cal >= TM_CAL_MAX) ? TM_CAL_MIN : (g_TM.cal + TM_CAL_STEP);
////            else         g_TM.cal = (g_TM.cal <= TM_CAL_MIN) ? TM_CAL_MAX : (g_TM.cal - TM_CAL_STEP);
////            break;
////        default: break;
////    }
////    if (is_limit) Beep_Play(BEEP_LIMIT);
////}

/////**
//// * @brief �����¼��ַ�
//// */
////void Treadmill_On_Event(uint8_t key_id, uint8_t evt) {
////    if (evt == K_EVT_RELEASE) return;
////    if (g_TM.state == TM_STATE_ERROR) {
////        if (key_id == K_ID_ONOFF && g_TM.safety_key) { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
////        return;
////    }
////    if ((key_id == K_ID_MODE || key_id == K_ID_ONOFF) && evt == K_EVT_HOLD) return;
////    if (g_TM.state == TM_STATE_BOOT) {
////        if (key_id == K_ID_ONOFF || key_id == K_ID_MODE) { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
////        return; 
////    } 
////    switch (g_TM.state) {
////        case TM_STATE_IDLE:
////            if (key_id == K_ID_ONOFF) {
////                Treadmill_Reset_Data(); g_TM.state = TM_STATE_COUNTDOWN; g_TM.timer_100ms = 30; 
////            } else if (key_id == K_ID_MODE) {
////                g_TM.state = TM_STATE_SETTING; g_TM.disp_index = DISP_TIME; g_TM.target_mode = TARGET_TIME; g_TM.time = TM_TIME_SET; 
////            }
////            break;
////        case TM_STATE_SETTING:
////            if (key_id == K_ID_MODE) {
////                if (g_TM.disp_index == DISP_TIME) { g_TM.disp_index = DISP_DIST; g_TM.target_mode = TARGET_DIST; g_TM.dist = TM_DIST_SET; } 
////                else if (g_TM.disp_index == DISP_DIST) { g_TM.disp_index = DISP_CAL; g_TM.target_mode = TARGET_CAL; g_TM.cal = TM_CAL_SET; } 
////                else { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
////            } else if (key_id == K_ID_UP || key_id == K_ID_DN) TM_Adjust_Process(key_id == K_ID_UP ? 1 : -1);
////            else if (key_id == K_ID_ONOFF) { g_TM.state = TM_STATE_COUNTDOWN; g_TM.timer_100ms = 30; }
////            break;
////        case TM_STATE_COUNTDOWN:
////            if (key_id == K_ID_ONOFF) { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
////            break;
////        case TM_STATE_RUNNING: 
////            if (key_id == K_ID_ONOFF) { 
////                g_TM.state = TM_STATE_STOPPING; g_TM.timer_100ms = TM_STOP_TIME_COUNT;
////                AeroLink_Send(FC_CONTROL, 0x01, (void*)0); 
////            } else if (key_id == K_ID_UP || key_id == K_ID_DN) {  
////                g_TM.disp_index = DISP_SPEED; g_TM.cycle_timer = 0; TM_Adjust_Process(key_id == K_ID_UP ? 1 : -1);
////            }                           
////            break;
////        default: break;
////    }
////    UI_MarkDirty(); 
////}

/////**
//// * @brief UI ��Ⱦ���֣�����ԭ����
//// */
////static void TM_UI_Dispatcher(void) {
////    if (g_TM.state == TM_STATE_BOOT) {
////        if (g_TM.timer_100ms == 0) Beep_Play(BEEP_CLICK); 
////        if (++g_TM.timer_100ms < 10) { for(uint8_t i=0; i<6; i++) UI_SetRaw(i, 0xFF); } 
////        else if (g_TM.timer_100ms < 25) { 
////            if (g_TM.timer_100ms == 10) UI_ClearAll();
////            UI_SetRaw(0, SEG_RAW(SEG_U)); UI_SetNumber(1, 10, 2, 2, ZERO_SHOW); 
////            UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
////        } 
////        else if (g_TM.timer_100ms < 40) { 
////            if (g_TM.timer_100ms == 25) UI_ClearAll();
////            UI_SetRaw(0, SEG_RAW(SEG_C)); UI_SetNumber(1, 1, 2, 2, ZERO_SHOW); 
////            UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
////        } 
////        else { g_TM.state = TM_STATE_IDLE; g_TM.timer_100ms = 0; }
////        return;
////    }
////    static TM_State_t s_last_state = TM_STATE_BOOT;
////    static TM_DispIndex_t s_last_disp = DISP_SPEED;
////    if (g_TM.state != s_last_state || g_TM.disp_index != s_last_disp) {
////        UI_ClearAll(); s_last_state = g_TM.state; s_last_disp = g_TM.disp_index;
////    }
////    for(uint8_t i=0; i<6; i++) UI_SetBitMode(GRID_IND, i, DISP_OFF); 
////    bool is_blink = (g_TM.state == TM_STATE_SETTING && g_TM.steady_timer == 0);
////    UI_SetBlinkTime(1000);
////    for(uint8_t i=0; i<4; i++) UI_SetGridBlinkMask(i, is_blink);
////    switch (g_TM.state) {
////        case TM_STATE_IDLE:
////            UI_SetNumber(1, 0, 3, 0, ZERO_SHOW); UI_SetBitMode(GRID_IND, LED_TIME, DISP_ON);
////            UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK); UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_BLINK);
////            break;
////        case TM_STATE_COUNTDOWN: {
////            uint8_t cd = (g_TM.timer_100ms + 9) / 10;
////            if (cd < 1) cd = 1; UI_SetNumber(2, cd, 1, 0, ZERO_HIDE); break;
////        }
////        case TM_STATE_STOPPING: 
////        case TM_STATE_SETTING:
////        case TM_STATE_RUNNING:
////            if (g_TM.state == TM_STATE_STOPPING || g_TM.disp_index == DISP_SPEED) {
////                if (g_TM.speed < 10) UI_SetNumber(1, g_TM.speed, 2, 0, ZERO_SHOW); 
////                else UI_SetNumber(0, g_TM.speed, 3, 0, ZERO_HIDE);
////                UI_SetBitMode(GRID_IND, LED_SPEED, DISP_ON); UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
////            } 
////            else if (g_TM.disp_index == DISP_TIME) {
////                uint8_t min = g_TM.time / 60; uint8_t sec = g_TM.time % 60;
////                uint16_t disp = min * 100 + sec;
////                if (min >= 10) UI_SetNumber(0, disp, 4, 2, ZERO_SHOW); else UI_SetNumber(1, disp, 3, 2, ZERO_SHOW);
////                UI_SetBitMode(GRID_IND, LED_TIME, DISP_ON);
////                UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK); UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_BLINK);
////            } 
////            else if (g_TM.disp_index == DISP_DIST) {
////                UI_SetNumber(0, (uint32_t)(g_TM.dist / 10.0f), 4, 3, ZERO_HIDE);
////                UI_SetBitMode(GRID_IND, LED_DIS, DISP_ON); UI_SetBitMode(GRID_COLON, SEG_COLON_L, is_blink ? DISP_BLINK : DISP_ON);
////            } 
////            else if (g_TM.disp_index == DISP_CAL) {
////                UI_SetNumber(0, (uint32_t)(g_TM.cal / 1000.0f), 4, 0, ZERO_HIDE); UI_SetBitMode(GRID_IND, LED_CAL, DISP_ON);
////            }
////            break;
////        case TM_STATE_ERROR: 
////            UI_SetRaw(0, SEG_RAW(SEG_E)); UI_SetNumber(1, g_TM.error_code, 2, 0, ZERO_SHOW); UI_SetRaw(3, 0); break;
////        default: break;     
////    }
////}

/////**
//// * @brief ���ջص����� (ģ�� cmd_proc �ṹ)
//// */
////void AeroLink_OnFrameReceived(AeroFrame_t *f) {
////    uint8_t fc = f->fc;
////    uint8_t sfc = f->sfc;

////    switch (fc) {
////        case 0x01: // �����������Ϣ
////            if (sfc == 0x00) { 
////                // data[1] ��Ӧ d1_l: �����ٶ�
////                s_fbk_speed = f->data[1]; 
////                // data[3] ��Ӧ d2_l: ����״̬ (0:��ʼ, 7:�ȴ�, 9:����, 10:ֹͣ)
////                s_lower_status = f->data[3]; 

////                // ״̬���Զ�ͬ���߼�
////                if ((s_lower_status == 10 || s_lower_status == 7) && 
////                    (g_TM.state == TM_STATE_RUNNING || g_TM.state == TM_STATE_STOPPING)) {
////                    g_TM.state = TM_STATE_IDLE; 
////                    Treadmill_Reset_Data();
////                }
////                UI_MarkDirty();
////            } 
////            else if (sfc == 0x01) { 
////                // һ�����Ͻ��� (d1_h << 8 | d1_l)
////                uint16_t err_raw = (uint16_t)((f->data[0] << 8) | f->data[1]);
////                // �������Ͻ��� (d2_l)
////                uint8_t  err_sub = f->data[3];

////                if (err_raw > 0 || err_sub > 0) {
////                    // ����ת���߼��������λ���룬�ҳ���һ������λ
////                    uint16_t code = 0;
////                    if (err_raw) {
////                        for (uint8_t i=0; i<13; i++) { if (err_raw & (1<<i)) { code = i+1; break; } }
////                    } else if (err_sub) {
////                        if (err_sub & 0x01) code = 14; else if (err_sub & 0x02) code = 15;
////                    }
////                    if (code) TM_Trigger_Error(code);
////                }
////            }
////            break;

////        case 0x02: // ģ������Ϣ
////            if (sfc == 0x00) {
////                // ģ�� cmd_proc �¶Ƚ�����ƴ�Ӳ�����1λ
////                s_sys_temp = (uint16_t)((((uint16_t)f->data[4] << 8) | f->data[5]) >> 1);
////            }
////            break;
////    }
////}

/////**
//// * @brief ���� 100ms �������
//// */
////void Treadmill_Manager_100ms(void) {
////    static float s_accum_dist = 0.0f;
////    static uint16_t s_stop_start_speed = 0;
////    static uint8_t s_sync_check_tick = 0;

////    if (++s_heartbeat_tick >= 5) { s_heartbeat_tick = 0; AeroLink_Send(FC_HEARTBEAT, 0x00, (void*)0); }
////    if (g_TM.state == TM_STATE_ERROR) { TM_UI_Dispatcher(); return; }
////    if (g_TM.steady_timer > 0 && --g_TM.steady_timer == 0) UI_MarkDirty();

////    if (g_TM.state == TM_STATE_COUNTDOWN) {
////        if (g_TM.timer_100ms > 0) {
////            if (g_TM.timer_100ms % 10 == 0) Beep_Play(BEEP_CLICK);
////            g_TM.timer_100ms--;
////        } else {
////            g_TM.state = TM_STATE_RUNNING; s_accum_dist = 0.0f;
////            AeroLink_Send(FC_CONTROL, 0x00, (void*)0); Send_Speed_To_Lower(); 
////        }
////    }

////    if (g_TM.state == TM_STATE_RUNNING) {
////        if (++s_sync_check_tick >= 10) { 
////            s_sync_check_tick = 0;
////            if (s_lower_status != 9) AeroLink_Send(FC_CONTROL, 0x00, (void*)0);
////            Send_Speed_To_Lower(); 
////        }

////        // �ٶ�У���߼� (�Ż��ݲ���������)
////        int16_t diff = (int16_t)g_TM.speed - (int16_t)s_fbk_speed;
////        if (diff < 0) diff = -diff;

////        if (diff > SPEED_TOLERANCE) {
////            // ��������ٶ��ڱ仯��˵��������ƶ���������
////            if (s_fbk_speed != s_last_fbk_speed) {
////                s_speed_err_cnt = 0;
////            } else {
////                // ��������ٶ���������������ʱ����
////                if (++s_speed_err_cnt >= SPEED_SYNC_TIMEOUT) { TM_Trigger_Error(14); return; }
////            }
////        } else { s_speed_err_cnt = 0; }
////        s_last_fbk_speed = s_fbk_speed;

////        // �˶�����
////        static uint8_t sec_cnt = 0;
////        if (++sec_cnt >= 10) {
////            sec_cnt = 0;
////            float inc = (float)g_TM.speed / 36.0f; s_accum_dist += inc;
////            bool stop_flag = false;
////            if (g_TM.target_mode == TARGET_TIME) { if(g_TM.time > 0) g_TM.time--; else stop_flag = true; }
////            else { g_TM.time++; if(g_TM.time >= TM_TIME_MAX) stop_flag = true; }
////            if (g_TM.target_mode == TARGET_DIST) { g_TM.dist -= inc; if(g_TM.dist <= 0) stop_flag = true; } else g_TM.dist = s_accum_dist;
////            if (g_TM.target_mode == TARGET_CAL) { g_TM.cal -= inc*CAL_PER; if(g_TM.cal <= 0) stop_flag = true; } else g_TM.cal = s_accum_dist*CAL_PER;
////            if (stop_flag) { g_TM.state = TM_STATE_STOPPING; g_TM.timer_100ms = TM_STOP_TIME_COUNT; AeroLink_Send(FC_CONTROL, 0x01, (void*)0); }
////        }
////        if (g_TM.steady_timer == 0 && ++g_TM.cycle_timer >= 50) {
////            g_TM.cycle_timer = 0; g_TM.disp_index = (TM_DispIndex_t)((g_TM.disp_index + 1) % 4);
////        }
////    }

////    if (g_TM.state == TM_STATE_STOPPING) {
////        static uint8_t stop_retry = 0;
////        if (++stop_retry >= 10) { stop_retry = 0; if (s_lower_status != 10 && s_lower_status != 7) AeroLink_Send(FC_CONTROL, 0x01, (void*)0); }
////        if (g_TM.timer_100ms == TM_STOP_TIME_COUNT) s_stop_start_speed = g_TM.speed;
////        if (g_TM.timer_100ms > 0) {
////            g_TM.timer_100ms--;
////            g_TM.speed = (uint32_t)s_stop_start_speed * g_TM.timer_100ms / TM_STOP_TIME_COUNT;
////        } else {
////            g_TM.speed = 0; g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data();
////        }
////        UI_MarkDirty();
////    }
////    TM_UI_Dispatcher();
////}


////#include "treadmills.h"
////#include "ui_display.h"
////#include "plat_segment.h"
////#include "plat_beep.h"
////#include "plat_keyfun.h"
////#include "plat_aerolink.h"

/////* ���ò��� */
////#define TM_STOP_TIME_COUNT    50    // ֹͣ����ʱ�䣺50 * 100ms = 5 �� (�Լ�����ʱ�ļ���ʱ��)

////TM_Control_t g_TM;

////// ��̬ͨѶ��ر���
////static uint16_t s_heartbeat_tick = 0; // �������ͼ�ʱ
////static uint8_t  s_lower_status = 10;  // ׷���¿ط��ص�����״̬ (Ĭ��10:ͣ��)

/////* Ӳ��ָʾ�ƶ��� (GRID4) */
////#define GRID_IND       4   
////#define LED_SPEED      1   // SEG2
////#define LED_TIME       0   // SEG1
////#define LED_DIS        2   // SEG3
////#define LED_CAL        3   // SEG4

////#define GRID_COLON     4   
////#define SEG_COLON_H    5   // SEG6
////#define SEG_COLON_L    4   // SEG5

/////**
//// * @brief �����������·���ǰ�ٶȸ��¿�
//// */
////static void Send_Speed_To_Lower(void) {
////    uint8_t data[8] = {0};
////    data[0] = (uint8_t)(g_TM.speed >> 8);   // Data1 ��λ
////    data[1] = (uint8_t)(g_TM.speed & 0xFF); // Data1 ��λ
////    AeroLink_Send(FC_GEAR, 0x00, data);
////}

/////**
//// * @brief �����˶�����
//// */
////static void Treadmill_Reset_Data(void) {
////    g_TM.time	  = 0;
////    g_TM.dist     = 0.0f;
////    g_TM.cal      = 0.0f;
////    g_TM.speed    = TM_SPEED_MIN;
////    
////    g_TM.target_mode  = TARGET_NONE;
////    g_TM.disp_index   = DISP_TIME;
////    g_TM.steady_timer = 0;
////    g_TM.cycle_timer  = 0;
////    UI_ClearAll(); 
////}

/////**
//// * @brief ϵͳ��ʼ��
//// */
////void Treadmill_Init(void) {
////    g_TM.state      = TM_STATE_BOOT; 
////    g_TM.boot_phase = BOOT_FULL;
////    g_TM.safety_key = true; 
////    Treadmill_Reset_Data(); 
////}

/////**
//// * @brief �������ڴ��� (�Ӽ���)
//// */
////static void TM_Adjust_Process(int8_t dir) {
////    g_TM.steady_timer = 20; 
////    UI_MarkDirty();
////    bool is_limit = false;
////	
////    switch (g_TM.disp_index) {
////        case DISP_SPEED:
////            if (dir > 0) {
////                if (g_TM.speed >= TM_SPEED_MAX) is_limit = true;
////                else g_TM.speed += TM_SPEED_STEP;
////            } else {
////                if (g_TM.speed <= TM_SPEED_MIN) is_limit = true;
////                else g_TM.speed -= TM_SPEED_STEP;
////            }
////            if (g_TM.state == TM_STATE_RUNNING) {
////                Send_Speed_To_Lower();
////            }						
////            break;
////        case DISP_TIME:
////            if (dir > 0) g_TM.time = (g_TM.time >= TM_TIME_MAX) ? TM_TIME_MIN : (g_TM.time + TM_TIME_STEP);
////            else         g_TM.time = (g_TM.time <= TM_TIME_MIN) ? TM_TIME_MAX : (g_TM.time - TM_TIME_STEP);
////            break;
////        case DISP_DIST:
////            if (dir > 0) g_TM.dist = (g_TM.dist >= TM_DIST_MAX) ? TM_DIST_MIN : (g_TM.dist + TM_DIST_STEP);
////            else         g_TM.dist = (g_TM.dist <= TM_DIST_MIN) ? TM_DIST_MAX : (g_TM.dist - TM_DIST_STEP);
////            break;
////        case DISP_CAL:
////            if (dir > 0) g_TM.cal = (g_TM.cal >= TM_CAL_MAX) ? TM_CAL_MIN : (g_TM.cal + TM_CAL_STEP);
////            else         g_TM.cal = (g_TM.cal <= TM_CAL_MIN) ? TM_CAL_MAX : (g_TM.cal - TM_CAL_STEP);
////            break;
////        default: break;
////    }
////    if (is_limit) Beep_Play(BEEP_LIMIT);
////}

/////**
//// * @brief �����¼��ַ�
//// */
////void Treadmill_On_Event(uint8_t key_id, uint8_t evt) {
////    if (evt == K_EVT_RELEASE) return;
////	
////    // ����״̬��������
////    if (g_TM.state == TM_STATE_ERROR) {
////        if (key_id == K_ID_ONOFF && evt == K_EVT_PRESS && g_TM.safety_key) {
////            g_TM.state = TM_STATE_IDLE;
////            Treadmill_Reset_Data();
////        }
////        return;
////    }
////		
////    if ((key_id == K_ID_MODE || key_id == K_ID_ONOFF) && evt == K_EVT_HOLD) return;
////    
////    if (g_TM.state == TM_STATE_BOOT) {
////        if (key_id == K_ID_ONOFF || key_id == K_ID_MODE) {
////            g_TM.state = TM_STATE_IDLE;
////            g_TM.timer_100ms = 0; 
////            Treadmill_Reset_Data();
////            UI_MarkDirty();
////        }
////        return; 
////    } 
////    
////    switch (g_TM.state) {
////        case TM_STATE_IDLE:
////            if (key_id == K_ID_UP || key_id == K_ID_DN) return; 
////            if (key_id == K_ID_ONOFF) {
////                Treadmill_Reset_Data();
////                g_TM.state = TM_STATE_COUNTDOWN; 
////                g_TM.timer_100ms = 30; 
////            } 
////            else if (key_id == K_ID_MODE) {
////                g_TM.state = TM_STATE_SETTING;
////                Treadmill_Reset_Data();
////                g_TM.disp_index = DISP_TIME;
////                g_TM.target_mode = TARGET_TIME;
////                g_TM.time = TM_TIME_SET; 
////            }
////            break;

////        case TM_STATE_SETTING:
////            if (key_id == K_ID_MODE) {
////                if (g_TM.disp_index == DISP_TIME) {
////                    g_TM.disp_index = DISP_DIST; g_TM.target_mode = TARGET_DIST;
////                    g_TM.dist = TM_DIST_SET;     
////                } else if (g_TM.disp_index == DISP_DIST) {
////                    g_TM.disp_index = DISP_CAL; g_TM.target_mode = TARGET_CAL;
////                    g_TM.cal = TM_CAL_SET;     
////                } else {
////                    g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data();
////                }
////            } 
////            else if (key_id == K_ID_UP || key_id == K_ID_DN) TM_Adjust_Process(key_id == K_ID_UP ? 1 : -1);
////            else if (key_id == K_ID_ONOFF) { g_TM.state = TM_STATE_COUNTDOWN; g_TM.timer_100ms = 30; }
////            break;
////                        
////        case TM_STATE_COUNTDOWN:
////            if (key_id == K_ID_ONOFF) { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
////            break;
////                        
////        case TM_STATE_RUNNING: 
////            if (key_id == K_ID_ONOFF) { 
////                g_TM.state = TM_STATE_STOPPING; 
////                g_TM.timer_100ms = TM_STOP_TIME_COUNT;     // ��ʼ���������ٵ���ʱ
////                AeroLink_Send(FC_CONTROL, 0x01, (void*)0); // �·�ָֹͣ��
////            }
////            else if (key_id == K_ID_UP || key_id == K_ID_DN) {  
////                g_TM.disp_index = DISP_SPEED; g_TM.cycle_timer = 0;
////                TM_Adjust_Process(key_id == K_ID_UP ? 1 : -1);
////            }                           
////            break;
////            
////        default: break;
////    }
////    UI_MarkDirty(); 
////}

/////**
//// * @brief UI ��Ⱦ���ķַ���
//// */
////static void TM_UI_Dispatcher(void) {
////    if (g_TM.state == TM_STATE_BOOT) {
////        if (g_TM.timer_100ms == 0) Beep_Play(BEEP_CLICK); 
////        if (++g_TM.timer_100ms < 10) { for(uint8_t i=0; i<6; i++) UI_SetRaw(i, 0xFF); } 
////        else if (g_TM.timer_100ms < 25) { 
////            if (g_TM.timer_100ms == 10) UI_ClearAll();
////            UI_SetRaw(0, SEG_RAW(SEG_U)); UI_SetNumber(1, 10, 2, 2, ZERO_SHOW); 
////            UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
////        } 
////        else if (g_TM.timer_100ms < 40) { 
////            if (g_TM.timer_100ms == 25) UI_ClearAll();
////            UI_SetRaw(0, SEG_RAW(SEG_C)); UI_SetNumber(1, 1, 2, 2, ZERO_SHOW); 
////            UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
////        } 
////        else { g_TM.state = TM_STATE_IDLE; g_TM.timer_100ms = 0; }
////        return;
////    }
////    
////    static TM_State_t s_last_state = TM_STATE_BOOT;
////    static TM_DispIndex_t s_last_disp = DISP_SPEED;

////    if (g_TM.state != s_last_state || g_TM.disp_index != s_last_disp) {
////        UI_ClearAll(); s_last_state = g_TM.state; s_last_disp = g_TM.disp_index;
////    }

////    for(uint8_t i=0; i<6; i++) UI_SetBitMode(GRID_IND, i, DISP_OFF); 
////    
////    bool is_blink = (g_TM.state == TM_STATE_SETTING && g_TM.steady_timer == 0);
////    UI_SetBlinkTime(1000);
////    for(uint8_t i=0; i<4; i++) UI_SetGridBlinkMask(i, is_blink);
////    
////    switch (g_TM.state) {
////        case TM_STATE_IDLE:
////            UI_SetNumber(1, 0, 3, 0, ZERO_SHOW); 
////            UI_SetBitMode(GRID_IND, LED_TIME, DISP_ON);
////            UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK);
////            UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_BLINK);
////            break;

////        case TM_STATE_COUNTDOWN: {
////            uint8_t cd = (g_TM.timer_100ms + 9) / 10;
////            if (cd < 1) cd = 1;
////            UI_SetNumber(2, cd, 1, 0, ZERO_HIDE); 
////            break;
////        }

////        // ֹͣ������̬�У�����ٶȵ���ʾͳһ���� (����ʾ g_TM.speed)
////        case TM_STATE_STOPPING: 
////        case TM_STATE_SETTING:
////        case TM_STATE_RUNNING:
////            if (g_TM.state == TM_STATE_STOPPING || g_TM.disp_index == DISP_SPEED) {
////                if (g_TM.speed < 10) {
////                    UI_SetNumber(1, g_TM.speed, 2, 0, ZERO_SHOW); 
////                } else {
////                    UI_SetNumber(0, g_TM.speed, 3, 0, ZERO_HIDE);
////                }
////                UI_SetBitMode(GRID_IND, LED_SPEED, DISP_ON);
////                UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON); // С����
////            } 
////            else if (g_TM.disp_index == DISP_TIME) {
////                uint8_t min = g_TM.time / 60; 
////                uint8_t sec = g_TM.time % 60;
////                uint16_t disp = min * 100 + sec;
////                if (min >= 10) UI_SetNumber(0, disp, 4, 2, ZERO_SHOW);
////                else UI_SetNumber(1, disp, 3, 2, ZERO_SHOW);
////                UI_SetBitMode(GRID_IND, LED_TIME, DISP_ON);
////                UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK);
////                UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_BLINK);
////            } 
////            else if (g_TM.disp_index == DISP_DIST) {
////                UI_SetNumber(0, (uint32_t)(g_TM.dist / 10.0f), 4, 3, ZERO_HIDE);
////                UI_SetBitMode(GRID_IND, LED_DIS, DISP_ON);
////                UI_SetBitMode(GRID_COLON, SEG_COLON_L, is_blink ? DISP_BLINK : DISP_ON);
////            } 
////            else if (g_TM.disp_index == DISP_CAL) {
////                UI_SetNumber(0, (uint32_t)(g_TM.cal / 1000.0f), 4, 0, ZERO_HIDE);
////                UI_SetBitMode(GRID_IND, LED_CAL, DISP_ON);
////            }
////            break;
////                        
////        case TM_STATE_ERROR: 
////            UI_SetRaw(0, SEG_RAW(SEG_E));
////            UI_SetNumber(1, g_TM.error_code, 2, 0, ZERO_SHOW); 
////            UI_SetRaw(3, 0); 
////            break;

////        default: break;     
////    }
////}

/////**
//// * @brief ����ʽ���ϴ�����
//// */
////static void TM_Trigger_Error(uint16_t err_code) {
////    if (g_TM.state == TM_STATE_ERROR && g_TM.error_code == err_code) return;

////    if (g_TM.state != TM_STATE_ERROR || g_TM.error_code != err_code) {
////        g_TM.state = TM_STATE_ERROR;
////        g_TM.error_code = err_code;
////        Beep_Play(BEEP_ALARM); 
////        UI_MarkDirty();
////    }
////}

/////**
//// * @brief ���Ļص������¿����κ����ݷ���ʱ����
//// */
////void AeroLink_OnFrameReceived(AeroFrame_t *f) {
////    /* 1. ����������Ϣ (������ȼ�) */
////    if (f->fc == 0x01 && f->sfc == 0x01) {
////        uint16_t err_lv1 = (f->data[0] << 8) | f->data[1]; 
////        uint8_t  err_lv2 = f->data[3]; 

////        if (err_lv1 != 0 || err_lv2 != 0) {
////            uint16_t code = 0;
////            for (uint8_t i = 0; i < 13; i++) {
////                if (err_lv1 & (1 << i)) { code = i + 1; break; }
////            }
////            if (!code) {
////                if (err_lv2 & 0x01) code = 14; 
////                else if (err_lv2 & 0x02) code = 15; 
////            }
////            if (code) TM_Trigger_Error(code); 
////            return; 
////        }
////    }

////    /* 2. ��������״̬��Ϣ */
////    if (g_TM.state == TM_STATE_BOOT || g_TM.state == TM_STATE_ERROR) return;

////    if (f->fc == 0x01 && f->sfc == 0x00) {
////        s_lower_status = f->data[2]; // ��¼�¿���ʵ����״̬
////        
////        switch (s_lower_status) {
////            case 9: // ����
////                if(g_TM.state == TM_STATE_IDLE || g_TM.state == TM_STATE_COUNTDOWN) {
////                    g_TM.state = TM_STATE_RUNNING; 
////                }
////                break;
////            case 10: // ֹͣ
////                // �յ��¿�����ֹͣ״̬��Ҳ�����лش��� (˫�ر���)
////                if(g_TM.state == TM_STATE_RUNNING || g_TM.state == TM_STATE_STOPPING) {
////                    g_TM.state = TM_STATE_IDLE; 
////                    Treadmill_Reset_Data();
////                } 
////                break;
////            case 3: // ����
////                g_TM.state = TM_STATE_ERROR;
////                break;
////        }
////        UI_MarkDirty();
////    }
////}

/////**
//// * @brief ���� 100ms �������
//// */
////void Treadmill_Manager_100ms(void)
////{
////    static float s_accum_dist = 0.0f;
////    static uint16_t s_stop_start_speed = 0; // ��¼��ʼͣ��ʱ�ĳ�ʼ�ٶ�

////    /* ͨѶ�������� */
////    if (++s_heartbeat_tick >= 5) {
////        s_heartbeat_tick = 0;
////        AeroLink_Send(FC_HEARTBEAT, 0x00, (void*)0); 
////    }

////    // ����״̬����
////    if (g_TM.state == TM_STATE_ERROR) {
////        TM_UI_Dispatcher();
////        return;
////    }
////		
////    if (g_TM.steady_timer > 0 && --g_TM.steady_timer == 0) UI_MarkDirty();

////    /* ����ʱ�߼� */
////    if (g_TM.state == TM_STATE_COUNTDOWN) {
////        if (g_TM.timer_100ms > 0) {
////            g_TM.timer_100ms--;
////            if (g_TM.timer_100ms == 20 || g_TM.timer_100ms == 10) Beep_Play(BEEP_CLICK);
////        } else {
////            g_TM.state = TM_STATE_RUNNING;
////            g_TM.cycle_timer = 0; 
////            g_TM.disp_index = DISP_SPEED; 
////            s_accum_dist = 0.0f;
////            if (g_TM.target_mode != TARGET_TIME) g_TM.time = 0;
////            if (g_TM.target_mode != TARGET_DIST) g_TM.dist = 0.0f;
////            if (g_TM.target_mode != TARGET_CAL)  g_TM.cal  = 0.0f;
////            AeroLink_Send(FC_CONTROL, 0x00, (void*)0); // ��������ָ��
////            Send_Speed_To_Lower(); 
////        }
////    }

////    /* ����̬�߼� */
////    if (g_TM.state == TM_STATE_RUNNING) {
////        
////        // ����ָ��������ش� (����¿�һֱû����9����̬��ÿ�벹��һ��)
////        static uint8_t retry_start = 0;
////        if (s_lower_status != 9 && s_lower_status != 3) {
////            if (++retry_start >= 10) { 
////                retry_start = 0;
////                AeroLink_Send(FC_CONTROL, 0x00, (void*)0);
////            }
////        } else { retry_start = 0; }

////        // ���ݼ����߼�
////        static uint8_t sec_cnt = 0;
////        if (++sec_cnt >= 10) {
////            sec_cnt = 0;
////            bool trigger_stop = false;
////            float dist_inc = (float)g_TM.speed / 36.0f; 
////            s_accum_dist += dist_inc;
////            
////            if (g_TM.target_mode == TARGET_TIME) {
////                if (g_TM.time > 0) g_TM.time--; if (g_TM.time == 0) trigger_stop = true;
////            } else { g_TM.time++; if (g_TM.time >= TM_TIME_MAX) trigger_stop = true; }
////            
////            if (g_TM.target_mode == TARGET_DIST) {
////                g_TM.dist -= dist_inc; if (g_TM.dist <= 0.0f) trigger_stop = true; 
////            } else { g_TM.dist = s_accum_dist; }
////            
////            if (g_TM.target_mode == TARGET_CAL) {
////                float cal_dec = dist_inc * CAL_PER;
////                g_TM.cal -= cal_dec; if (g_TM.cal <= 0.0f) trigger_stop = true;
////            } else { g_TM.cal = s_accum_dist * CAL_PER; }

////            // �����Զ�ͣ��
////            if (trigger_stop) {
////                g_TM.state = TM_STATE_STOPPING; 
////                g_TM.timer_100ms = TM_STOP_TIME_COUNT; 
////                Beep_Play(BEEP_CLICK); 
////                AeroLink_Send(FC_CONTROL, 0x01, (void*)0); 
////            }
////        }
////        
////        // �����߼�
////        if (g_TM.steady_timer == 0 && ++g_TM.cycle_timer >= 50) {
////            g_TM.cycle_timer = 0;
////            g_TM.disp_index = (TM_DispIndex_t)((g_TM.disp_index + 1) % 4);
////        }
////    }

////    /* ͣ��������ʾ�߼� (���������㣬��0���̴���) */
////    if (g_TM.state == TM_STATE_STOPPING) {
////        
////        // ָֹͣ��������ش�
////        static uint8_t retry_stop = 0;
////        if (s_lower_status != 10 && s_lower_status != 3) {
////            if (++retry_stop >= 10) { 
////                retry_stop = 0;
////                AeroLink_Send(FC_CONTROL, 0x01, (void*)0);
////            }
////        } else { retry_stop = 0; }

////        // �ս���ֹͣ״̬ʱ�����浱ǰ�ٶ���Ϊ�ݼ���׼
////        if (g_TM.timer_100ms == TM_STOP_TIME_COUNT) {
////            s_stop_start_speed = g_TM.speed;
////        }

////        // ����ʱ�ݼ�����Ŀ���ٶ�����UI��ʾ
////        if (g_TM.timer_100ms > 0) {
////            g_TM.timer_100ms--;
////            g_TM.speed = (uint32_t)s_stop_start_speed * g_TM.timer_100ms / TM_STOP_TIME_COUNT;
////        } else {
////            g_TM.speed = 0; 
////        }

////        // �����޸ģ�ֻҪ�ٶ���ʾ�ﵽ 0��������ԥֱ���л��ش���״̬����λ��������
////        if (g_TM.speed == 0) {
////            g_TM.state = TM_STATE_IDLE;
////            Treadmill_Reset_Data();
////        } else {
////            // ����ٶȻ�û�� 0������ˢ�¼��ٶ���
////            UI_MarkDirty(); 
////        }
////    }
////				
////    TM_UI_Dispatcher();
////}

#include "treadmills.h"
#include "ui_display.h"
#include "plat_segment.h"
#include "plat_beep.h"
#include "plat_keyfun.h"
#include "plat_aerolink.h"

/* ���ò��� */
#define TM_STOP_TIME_COUNT    50    
#define SPEED_SYNC_TIMEOUT    60    // 6��ͬ����ʱ
#define MAX_CMD_LEAD          25    // ָ�����ȷ���������ֵ��2.5 km/h
/* Ӳ��ָʾ�ƶ��� (GRID4) */
#define GRID_IND       4   
#define LED_SPEED      1   // SEG2
#define LED_TIME       0   // SEG1
#define LED_DIS        2   // SEG3
#define LED_CAL        3   // SEG4

#define GRID_COLON     4   
#define SEG_COLON_H    5   // SEG6
#define SEG_COLON_L    4   // SEG5
TM_Control_t g_TM;

static uint16_t s_heartbeat_tick = 0; 
static uint8_t  s_lower_status = 10;   
static uint16_t s_fbk_speed = 0;       
static uint16_t s_last_fbk_speed = 0;  
static uint8_t  s_speed_err_cnt = 0;   
static uint16_t s_sys_temp = 0;        

/**
 * @brief �·��ٶ�
 */
static void Send_Speed_To_Lower(void) {
    uint8_t data[8] = {0};
    data[0] = (uint8_t)(g_TM.speed >> 8);   
    data[1] = (uint8_t)(g_TM.speed & 0xFF); 
    AeroLink_Send(FC_GEAR, 0x00, data);
}

/**
 * @brief ���ϴ���
 */
static void TM_Trigger_Error(uint16_t err_code) {
    if (g_TM.state == TM_STATE_ERROR && g_TM.error_code == err_code) return;
    g_TM.state = TM_STATE_ERROR;
    g_TM.error_code = err_code;
    Beep_Play(BEEP_ALARM); 
    UI_MarkDirty();
}

/**
 * @brief ���ݸ�λ
 */
static void Treadmill_Reset_Data(void) {
    g_TM.time = 0; g_TM.dist = 0.0f; g_TM.cal = 0.0f;
    g_TM.speed = TM_SPEED_MIN;
    g_TM.target_mode = TARGET_NONE;
    g_TM.disp_index = DISP_SPEED; // Ĭ�ϸ�Ϊ�ٶȵ�
    g_TM.steady_timer = 0; g_TM.cycle_timer = 0;
    s_speed_err_cnt = 0; s_fbk_speed = 0; s_last_fbk_speed = 0;
    UI_ClearAll(); 
}

void Treadmill_Init(void) {
    g_TM.state = TM_STATE_BOOT; g_TM.safety_key = true; Treadmill_Reset_Data(); 
}

/**
 * @brief ��������(�Ӽ���)
 */
static void TM_Adjust_Process(int8_t dir) {
    g_TM.steady_timer = 30; // ���ں���������3�벻��ת
    UI_MarkDirty();
    switch (g_TM.disp_index) {
        case DISP_SPEED:
            if (dir > 0) {
                if (g_TM.speed >= TM_SPEED_MAX) Beep_Play(BEEP_LIMIT);
                else if (g_TM.state == TM_STATE_RUNNING && (g_TM.speed > s_fbk_speed + MAX_CMD_LEAD)) return; 
                else g_TM.speed += TM_SPEED_STEP;
            } else {
                if (g_TM.speed <= TM_SPEED_MIN) Beep_Play(BEEP_LIMIT);
                else g_TM.speed -= TM_SPEED_STEP;
            }
            if (g_TM.state == TM_STATE_RUNNING) Send_Speed_To_Lower();
            break;
        case DISP_TIME:
            if (dir > 0) g_TM.time = (g_TM.time >= TM_TIME_MAX) ? TM_TIME_MIN : (g_TM.time + TM_TIME_STEP);
            else         g_TM.time = (g_TM.time <= TM_TIME_MIN) ? TM_TIME_MAX : (g_TM.time - TM_TIME_STEP);
            break;
        case DISP_DIST:
            if (dir > 0) g_TM.dist = (g_TM.dist >= TM_DIST_MAX) ? TM_DIST_MIN : (g_TM.dist + TM_DIST_STEP);
            else         g_TM.dist = (g_TM.dist <= TM_DIST_MIN) ? TM_DIST_MAX : (g_TM.dist - TM_DIST_STEP);
            break;
        case DISP_CAL:
            if (dir > 0) g_TM.cal = (g_TM.cal >= TM_CAL_MAX) ? TM_CAL_MIN : (g_TM.cal + TM_CAL_STEP);
            else         g_TM.cal = (g_TM.cal <= TM_CAL_MIN) ? TM_CAL_MAX : (g_TM.cal - TM_CAL_STEP);
            break;
        default: break;
    }
}

/**
 * @brief �����¼���������
 */
void Treadmill_On_Event(uint8_t key_id, uint8_t evt) {
    if (evt == K_EVT_RELEASE) return;
    
    // ��������
    if (g_TM.state == TM_STATE_ERROR) {
        if (key_id == K_ID_ONOFF && g_TM.safety_key) { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
        return;
    }

    // ����/ģʽ������Ч
    if ((key_id == K_ID_MODE || key_id == K_ID_ONOFF) && evt == K_EVT_HOLD) return;

    // ���� LOGO ����
    if (g_TM.state == TM_STATE_BOOT) {
        if (key_id == K_ID_ONOFF || key_id == K_ID_MODE) { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
        return; 
    } 

    switch (g_TM.state) {
        case TM_STATE_IDLE:
            if (key_id == K_ID_ONOFF) {
                Treadmill_Reset_Data(); g_TM.state = TM_STATE_COUNTDOWN; g_TM.timer_100ms = 30; 
            } else if (key_id == K_ID_MODE) {
                g_TM.state = TM_STATE_SETTING; g_TM.disp_index = DISP_TIME; g_TM.target_mode = TARGET_TIME; g_TM.time = TM_TIME_SET; 
            }
            break;

        case TM_STATE_SETTING:
            if (key_id == K_ID_MODE) {
                if (g_TM.disp_index == DISP_TIME) { g_TM.disp_index = DISP_DIST; g_TM.target_mode = TARGET_DIST; g_TM.dist = TM_DIST_SET; } 
                else if (g_TM.disp_index == DISP_DIST) { g_TM.disp_index = DISP_CAL; g_TM.target_mode = TARGET_CAL; g_TM.cal = TM_CAL_SET; } 
                else { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
            } else if (key_id == K_ID_UP || key_id == K_ID_DN) {
                TM_Adjust_Process(key_id == K_ID_UP ? 1 : -1);
            } else if (key_id == K_ID_ONOFF) {
                g_TM.state = TM_STATE_COUNTDOWN; g_TM.timer_100ms = 30;
            }
            break;

        case TM_STATE_COUNTDOWN:
            if (key_id == K_ID_ONOFF) { g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data(); }
            break;

        case TM_STATE_RUNNING: 
            if (key_id == K_ID_ONOFF) { 
                g_TM.state = TM_STATE_STOPPING; g_TM.timer_100ms = TM_STOP_TIME_COUNT;
                AeroLink_Send(FC_CONTROL, 0x01, (void*)0); 
            } 
            else if (key_id == K_ID_MODE) { // ���޸����������л������߼�
                g_TM.steady_timer = 50; // �ֶ��л������� 5 �벻��ת
                g_TM.disp_index = (TM_DispIndex_t)((g_TM.disp_index + 1) % 4);
                Beep_Play(BEEP_CLICK);
            }
            else if (key_id == K_ID_UP || key_id == K_ID_DN) {  
                g_TM.disp_index = DISP_SPEED; // ����ʱ�Զ��л��ٶ���ʾ
                g_TM.cycle_timer = 0; 
                TM_Adjust_Process(key_id == K_ID_UP ? 1 : -1);
            }                           
            break;
        default: break;
    }
    UI_MarkDirty(); 
}

/* UI ��Ⱦ (�߼��ȶ���δ���ṹ�Ķ�) */
static void TM_UI_Dispatcher(void) {
    if (g_TM.state == TM_STATE_BOOT) {
        if (g_TM.timer_100ms == 0) Beep_Play(BEEP_CLICK); 
        if (++g_TM.timer_100ms < 10) { for(uint8_t i=0; i<6; i++) UI_SetRaw(i, 0xFF); } 
        else if (g_TM.timer_100ms < 25) { 
            if (g_TM.timer_100ms == 10) UI_ClearAll();
            UI_SetRaw(0, SEG_RAW(SEG_U)); UI_SetNumber(1, 10, 2, 2, ZERO_SHOW); 
            UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
        } 
        else if (g_TM.timer_100ms < 40) { 
            if (g_TM.timer_100ms == 25) UI_ClearAll();
            UI_SetRaw(0, SEG_RAW(SEG_C)); UI_SetNumber(1, 1, 2, 2, ZERO_SHOW); 
            UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
        } 
        else { g_TM.state = TM_STATE_IDLE; g_TM.timer_100ms = 0; }
        return;
    }
    static TM_State_t s_last_state = TM_STATE_BOOT;
    static TM_DispIndex_t s_last_disp = DISP_SPEED;
    if (g_TM.state != s_last_state || g_TM.disp_index != s_last_disp) {
        UI_ClearAll(); s_last_state = g_TM.state; s_last_disp = g_TM.disp_index;
    }
    for(uint8_t i=0; i<6; i++) UI_SetBitMode(GRID_IND, i, DISP_OFF); 
    bool is_blink = (g_TM.state == TM_STATE_SETTING && g_TM.steady_timer == 0);
    UI_SetBlinkTime(1000);
    for(uint8_t i=0; i<4; i++) UI_SetGridBlinkMask(i, is_blink);
    switch (g_TM.state) {
        case TM_STATE_IDLE:
            UI_SetNumber(1, 0, 3, 0, ZERO_SHOW); UI_SetBitMode(GRID_IND, LED_TIME, DISP_ON);
            UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK); UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_BLINK);
            break;
        case TM_STATE_COUNTDOWN: {
            uint8_t cd = (g_TM.timer_100ms + 9) / 10;
            if (cd < 1) cd = 1; UI_SetNumber(2, cd, 1, 0, ZERO_HIDE); break;
        }
        case TM_STATE_STOPPING: 
        case TM_STATE_SETTING:
        case TM_STATE_RUNNING:
            if (g_TM.state == TM_STATE_STOPPING || g_TM.disp_index == DISP_SPEED) {
                if (g_TM.speed < 10) UI_SetNumber(1, g_TM.speed, 2, 0, ZERO_SHOW); 
                else UI_SetNumber(0, g_TM.speed, 3, 0, ZERO_HIDE);
                UI_SetBitMode(GRID_IND, LED_SPEED, DISP_ON); UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
            } 
            else if (g_TM.disp_index == DISP_TIME) {
                uint16_t disp = (g_TM.time / 60) * 100 + (g_TM.time % 60);
                if (g_TM.time / 60 >= 10) UI_SetNumber(0, disp, 4, 2, ZERO_SHOW); else UI_SetNumber(1, disp, 3, 2, ZERO_SHOW);
                UI_SetBitMode(GRID_IND, LED_TIME, DISP_ON);
                UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK); UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_BLINK);
            } 
            else if (g_TM.disp_index == DISP_DIST) {
                UI_SetNumber(0, (uint32_t)(g_TM.dist / 10.0f), 4, 3, ZERO_HIDE);
                UI_SetBitMode(GRID_IND, LED_DIS, DISP_ON); UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_ON);
            } 
            else if (g_TM.disp_index == DISP_CAL) {
                UI_SetNumber(0, (uint32_t)(g_TM.cal / 1000.0f), 4, 0, ZERO_HIDE); UI_SetBitMode(GRID_IND, LED_CAL, DISP_ON);
            }
            break;
        case TM_STATE_ERROR: 
            UI_SetRaw(0, SEG_RAW(SEG_E)); UI_SetNumber(1, g_TM.error_code, 2, 0, ZERO_SHOW); UI_SetRaw(3, 0); break;
        default: break;     
    }
}

/**
 * @brief ���մ���
 */
void AeroLink_OnFrameReceived(AeroFrame_t *f) {
    if (f->fc == 0x01) {
        if (f->sfc == 0x00) { 
            s_fbk_speed = f->data[1]; 
            s_lower_status = f->data[3]; 
            if ((s_lower_status == 10 || s_lower_status == 7) && (g_TM.state == TM_STATE_RUNNING || g_TM.state == TM_STATE_STOPPING)) {
                g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data();
            }
            UI_MarkDirty();
        } 
        else if (f->sfc == 0x01) { 
            uint16_t err_raw = (uint16_t)((f->data[0] << 8) | f->data[1]);
            uint8_t  err_sub = f->data[3];
            if (err_raw || err_sub) {
                uint16_t code = 0;
                if (err_raw) { for (uint8_t i=0; i<13; i++) { if (err_raw & (1<<i)) { code = i+1; break; } } }
                else if (err_sub) { if (err_sub & 0x01) code = 14; else if (err_sub & 0x02) code = 15; }
                if (code) TM_Trigger_Error(code);
            }
        }
    } else if (f->fc == 0x02 && f->sfc == 0x00) {
        s_sys_temp = (uint16_t)((((uint16_t)f->data[4] << 8) | f->data[5]) >> 1);
    }
}

/**
 * @brief 100ms ���ĵ���
 */
void Treadmill_Manager_100ms(void) {
    static float s_accum_dist = 0.0f;
    static uint16_t s_stop_start_speed = 0;
    static uint8_t s_sync_check_tick = 0;

    if (++s_heartbeat_tick >= 5) { s_heartbeat_tick = 0; AeroLink_Send(FC_HEARTBEAT, 0x00, (void*)0); }
    if (g_TM.state == TM_STATE_ERROR) { TM_UI_Dispatcher(); return; }
    if (g_TM.steady_timer > 0) g_TM.steady_timer--;

    if (g_TM.state == TM_STATE_COUNTDOWN) {
        if (g_TM.timer_100ms > 0) {
            if (g_TM.timer_100ms % 10 == 0) Beep_Play(BEEP_CLICK);
            g_TM.timer_100ms--;
        } else {
            g_TM.state = TM_STATE_RUNNING; 
            s_accum_dist = 0.0f;
            g_TM.disp_index = DISP_SPEED; // ���ؼ�����������ǿ���л����ٶȽ���
            AeroLink_Send(FC_CONTROL, 0x00, (void*)0); 
            Send_Speed_To_Lower(); 
        }
    }

    if (g_TM.state == TM_STATE_RUNNING) {
        if (++s_sync_check_tick >= 10) { 
            s_sync_check_tick = 0;
            if (s_lower_status != 9) AeroLink_Send(FC_CONTROL, 0x00, (void*)0);
            Send_Speed_To_Lower(); 
        }

        // �ٶ�У�� (����)
        int16_t diff = (int16_t)g_TM.speed - (int16_t)s_fbk_speed;
        if (diff < 0) diff = -diff;
        if (diff > 5) { 
            if (s_fbk_speed != s_last_fbk_speed) s_speed_err_cnt = 0;
            else if (++s_speed_err_cnt >= SPEED_SYNC_TIMEOUT) { TM_Trigger_Error(14); return; }
        } else { s_speed_err_cnt = 0; }
        s_last_fbk_speed = s_fbk_speed;

        // �˶�����
        static uint8_t sec_cnt = 0;
        if (++sec_cnt >= 10) {
            sec_cnt = 0;
            float inc = (float)g_TM.speed / 36.0f; s_accum_dist += inc;
            bool stop_flag = false;
            if (g_TM.target_mode == TARGET_TIME) { if(g_TM.time > 0) g_TM.time--; else stop_flag = true; }
            else { g_TM.time++; if(g_TM.time >= TM_TIME_MAX) stop_flag = true; }
            if (g_TM.target_mode == TARGET_DIST) { g_TM.dist -= inc; if(g_TM.dist <= 0) stop_flag = true; } else g_TM.dist = s_accum_dist;
            if (g_TM.target_mode == TARGET_CAL) { g_TM.cal -= inc*0.06f; if(g_TM.cal <= 0) stop_flag = true; } else g_TM.cal = s_accum_dist*0.06f;
            if (stop_flag) { g_TM.state = TM_STATE_STOPPING; g_TM.timer_100ms = TM_STOP_TIME_COUNT; AeroLink_Send(FC_CONTROL, 0x01, (void*)0); }
        }
        
        // �Զ������߼� (����û���ֶ�����ʱ)
        if (g_TM.steady_timer == 0) {
            if (++g_TM.cycle_timer >= 50) {
                g_TM.cycle_timer = 0;
                g_TM.disp_index = (TM_DispIndex_t)((g_TM.disp_index + 1) % 4);
                UI_MarkDirty();
            }
        } else {
            g_TM.cycle_timer = 0;
        }
    }

    if (g_TM.state == TM_STATE_STOPPING) {
        static uint8_t stop_retry = 0;
        if (++stop_retry >= 10) { stop_retry = 0; if (s_lower_status != 10 && s_lower_status != 7) AeroLink_Send(FC_CONTROL, 0.01, (void*)0); }
        if (g_TM.timer_100ms == TM_STOP_TIME_COUNT) s_stop_start_speed = g_TM.speed;
        if (g_TM.timer_100ms > 0) {
            g_TM.timer_100ms--;
            g_TM.speed = (uint32_t)s_stop_start_speed * g_TM.timer_100ms / TM_STOP_TIME_COUNT;
        } else {
            g_TM.speed = 0; g_TM.state = TM_STATE_IDLE; Treadmill_Reset_Data();
        }
        UI_MarkDirty();
    }
    TM_UI_Dispatcher();
}
