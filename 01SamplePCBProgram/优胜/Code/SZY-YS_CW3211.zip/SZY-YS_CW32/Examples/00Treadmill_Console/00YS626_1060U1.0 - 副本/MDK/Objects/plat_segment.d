./objects/plat_segment.o: ..\PLATFORM\plat_segment.c \
  ..\PLATFORM\plat_segment.h \
  D:\Software\Keil_V5\MDK\ARM\ARMCLANG\Bin\..\include\stdint.h
