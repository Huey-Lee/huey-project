#include "queue.h"

/* ��ʼ�� */
void queue_init(queue_t *q)
{
    q->write = 0;
    q->read  = 0;
}

/* ��ӣ��жϿ��ã� */
uint8_t queue_push(queue_t *q, uint8_t data)
{
    uint16_t next = (q->write + 1) & (QUEUE_SIZE - 1);

    /* ���� */
    if (next == q->read)
        return 0;

    q->buf[q->write] = data;
    q->write = next;

    return 1;
}

/* ���� */
uint8_t queue_pop(queue_t *q, uint8_t *data)
{
    if (q->read == q->write)
        return 0;

    *data = q->buf[q->read];
    q->read = (q->read + 1) & (QUEUE_SIZE - 1);

    return 1;
}

/* �Ƿ�Ϊ�� */
uint8_t queue_is_empty(queue_t *q)
{
    return (q->read == q->write);
}

/* �Ƿ��� */
uint8_t queue_is_full(queue_t *q)
{
    return (((q->write + 1) & (QUEUE_SIZE - 1)) == q->read);
}

/* ��ǰ������ */
uint16_t queue_size(queue_t *q)
{
    return (q->write - q->read) & (QUEUE_SIZE - 1);
}

