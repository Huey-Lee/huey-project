#ifndef __PLAT_RF_H
#define __PLAT_RF_H

#include "main.h"
#include <stdbool.h>

typedef enum {
    RF_TYPE_NONE = 0,
    RF_TYPE_24BIT,      // Э��1 (16λID + 8λ��ֵ)
    RF_TYPE_32BIT       // Э��2 (16λID + 8λ��ֵ + 8λУ��)
} RF_Type_t;

typedef struct {
    uint32_t addr;
    uint8_t  key;
    RF_Type_t type;
    volatile bool vld;  // ԭ���Ա�־λ
} RF_Msg_t;

extern RF_Msg_t g_rf_msg;

void RF433_Handler_60us(void);

#endif

