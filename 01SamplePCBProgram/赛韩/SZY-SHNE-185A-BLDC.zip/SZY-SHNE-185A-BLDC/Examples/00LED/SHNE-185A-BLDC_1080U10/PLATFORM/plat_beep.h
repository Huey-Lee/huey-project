#ifndef __PLAT_BEEP_H
#define __PLAT_BEEP_H

#include "main.h"

// 音效预设（HNR-1407A 谐振频率 4000Hz，统一用此频率，以节拍区分）
typedef enum {
    BEEP_CLICK = 0,    // 按键音：60ms 单声
    BEEP_LIMIT,        // 到限音：60ms×3 三声
    BEEP_ALARM,        // 报警音：100ms×10 急促（下控故障等）
    BEEP_POWER_ON,     // 开机音：300ms 长鸣
    BEEP_LONG,         // 单次长鸣（安全锁故障/复位等，避免滴滴多响）
    BEEP_CAP_SPEED_HI, /* 运行调速到最大速：高音单声 */
    BEEP_CAP_SPEED_LO, /* 运行调速到最小速：低音单声 */
} BeepMode_t;

void Beep_Init(void);
void Beep_Handler_1ms(void);
void Beep_Stop(void);              /* 立即停止当前蜂鸣 */
uint8_t Beep_IsBusy(void);         /* 正在播放中（含长鸣过程） */
void Beep_Play(BeepMode_t mode);
void Beep_Play_Custom(uint16_t freq, uint8_t vol, uint16_t on, uint16_t off, uint8_t count);

#endif
