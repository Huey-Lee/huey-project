/* Treadmill: UI/state, keys, lower-board link */
#include "treadmills.h"
#include "ui_display.h"
#include "plat_segment.h"
#include "plat_beep.h"
#include "plat_keyfun.h"
#include "plat_aerolink.h"

#define COMM_TIMEOUT_COUNT  50  /* no valid frame: 50*100ms = 5s */

TM_Control_t g_TM;

#if (LED_DRIVER_TYPE == LED_DRIVER_TM1640)
static uint8_t  s_tm1640_shared_cal;   /* 0=路程，1=卡路里 */
static uint16_t s_tm1640_swap_100ms;   /* 与 steady_timer/cycle_timer 脱钩，保证每 5s 切换 */

/* 跑马灯状态 */
static uint8_t  s_mq_on   = 0u;       /* 当前点亮灯数 0..12 */
static uint16_t s_mq_tick = 0u;       /* 步进计时（×100ms） */
static int8_t   s_mq_dir  = 1;        /* 空闲呼吸方向 +1/-1 */
#endif

static uint16_t g_comm_timeout_cnt = 0; /* no-frame counter, cleared on RX */
/* 下控 Data1 换算后的 0.1km/h（运行中用于与上显比对并重发档位） */
static uint16_t s_lower_spd_rx_tenth;
static uint16_t s_stop_initial_spd; /* 进入 STOPPING 时的速度(0.1km/h)，用于线性减速 */
static uint16_t s_stop_ramp_dur;    /* 本段停机斜坡总 tick（与 timer_100ms 初值一致） */
static int32_t  s_stop_ramp_err;    /* Bresenham 累加：在整段 dur 内均匀减 init 次 0.1 */
static uint8_t  s_lower_last_run_status = 10u; /* 下控最近 run_status；10=待机 */
static uint8_t  s_cd_run_resend_100ms;         /* 321 阶段启动命令重发间隔计数 */
static uint8_t  s_stop_cmd_resend_100ms;       /* STOP 重发间隔计数 */

/* 停机斜坡 tick：低速 init×k 缩短，高速顶格 TM_STOPPING_DURATION_100MS */
static uint16_t prv_stop_ramp_duration_ticks(uint16_t init_tenth) {
    uint32_t cap = (uint32_t)TM_STOPPING_DURATION_100MS;
    uint32_t lin = (uint32_t)init_tenth * (uint32_t)TM_STOP_TICKS_PER_TENTH;
    uint32_t mnr = (uint32_t)TM_STOP_MIN_RAMP_100MS;
    uint32_t eff = lin;
    if (eff < mnr) eff = mnr;
    if (eff > cap) eff = cap;
    if (eff < 1u) eff = 1u;
    return (uint16_t)eff;
}

/* TM1620/TM1652: indicator LEDs on logic grid GRID_IND */
#define GRID_IND    4
#define LED_SPEED   1
#define LED_TIME    0
#define LED_DIS     2
#define LED_CAL     3

/* Colon: TM1640 时间在逻辑格 3..6，冒号在位5(逻辑格4)；TM1620/1652 在格 0 */
#if (LED_DRIVER_TYPE == LED_DRIVER_TM1640)
#define GRID_COLON    4
#else
#define GRID_COLON    0
#endif
#if (LED_DRIVER_TYPE == LED_DRIVER_TM1640)
#define SEG_COLON_H   7  /* _SEG_DP -> UI_SEG_DP_HW */
#define SEG_COLON_L   7
#else
#define SEG_COLON_H   1
#define SEG_COLON_L   1
#endif


/* Time zone: minutes 0..99 for 0:mm (ceil remaining sec when target=time and running). */
static uint16_t TM_Time_Minutes_For_Display(void) {
    uint32_t t = g_TM.time;
    if (g_TM.target_mode == TARGET_TIME &&
        (g_TM.state == TM_STATE_RUNNING || g_TM.state == TM_STATE_STOPPING)) {
        if (t == 0u) return 0;
        uint32_t m = (t + 59u) / 60u;
        return (m > 99u) ? 99u : (uint16_t)m;
    }
    if (g_TM.target_mode == TARGET_TIME &&
        (g_TM.state == TM_STATE_SETTING || g_TM.state == TM_STATE_IDLE)) {
        uint32_t m = t / 60u;
        return (m > 99u) ? 99u : (uint16_t)m;
    }
    {
        uint32_t m = t / 60u;
        return (m > 99u) ? 99u : (uint16_t)m;
    }
}

/* TM1640 时间区 MM:SS：g_TM.time 为秒，显示上限 99:59 */
static uint16_t TM_Time_MMSS_For_Display(void) {
    uint32_t sec = g_TM.time;
    if (sec > 5999u) sec = 5999u;
    uint32_t mm = sec / 60u;
    uint32_t ss = sec % 60u;
    if (mm > 99u) {
        mm = 99u;
        ss = 59u;
    }
    return (uint16_t)(mm * 100u + ss);
}

/* Distance: g_TM.dist meters -> UI tenths of km (10 = 1.0 km, 50 = 5.0 km, 990 = 99.0 km). */
static uint16_t TM_Dist_Tenths_For_Display(void) {
    float d = g_TM.dist;
    if (d < 0.0f) d = 0.0f;
    uint32_t dk = (uint32_t)(d / 100.0f); /* 100 m == 0.1 km, truncate */
    if (dk > 990u) dk = 990u;
    return (uint16_t)dk;
}


static void Send_Speed_To_Lower(void) {
    uint8_t data[8] = {0};
    uint16_t s = g_TM.speed;
    data[1] = (s > 255u) ? 255u : (uint8_t)s; /* One byte on wire; clamp 0.1 km/h units to 255 */
    AeroLink_Send(FC_GEAR, 0x00, data);
}

static void Treadmill_Reset_Data(void) {
    g_TM.time             = 0;
    g_TM.dist             = 0.0f;
    g_TM.cal              = 0.0f;
    g_TM.speed            = 0;
    g_TM.target_mode      = TARGET_NONE;
    g_TM.disp_index       = DISP_TIME;
    g_TM.steady_timer     = 0;
    g_TM.cycle_timer      = 0;
    g_TM.prog_index       = 0;
    g_TM.prog_seg         = 0;
    g_TM.seg_elapsed_sec  = 0;
    g_TM.pending_lower_standby     = false;
    g_TM.lower_standby_wait_100ms  = 0;
    g_TM.timer_100ms               = 0;
    s_stop_ramp_err                = 0;
    s_stop_ramp_dur                = 0;
    s_stop_cmd_resend_100ms        = 0;
#if (LED_DRIVER_TYPE == LED_DRIVER_TM1640)
    s_tm1640_shared_cal  = 0;
    s_tm1640_swap_100ms  = 0;
    s_mq_on   = 0u;
    s_mq_tick = 0u;
    s_mq_dir  = 1;
#endif
    UI_ClearAll();
}

void Treadmill_Init(void) {
    g_TM.state      = TM_STATE_BOOT;
    g_TM.boot_phase = BOOT_FULL;
    Treadmill_Reset_Data();
}

/* ----------------------------------------------------------------
 * Program 速度表：12 程序 × 10 段，单位 0.1 km/h（30 = 3.0 km/h）
 * 每段 3 分钟，共 30 分钟
 * ---------------------------------------------------------------- */
#if (LED_DRIVER_TYPE == LED_DRIVER_TM1640)
static const uint16_t c_prog_speed[TM_PROG_COUNT][TM_PROG_SEG_COUNT] = {
    /* seg:  1    2    3    4    5    6    7    8    9   10  */
    /* P01 */{30,  30, 100,  60,  80,  80,  80,  80,  80,  30},
    /* P02 */{30,  30,  60,  60,  80,  80,  80,  80,  30,  30},
    /* P03 */{20,  30,  60, 100, 100, 100, 100,  20,  30,  20},
    /* P04 */{30,  60, 100, 100, 100, 100, 100,  60,  30,  30},
    /* P05 */{20,  20,  60,  60, 100, 100,  80,  60,  30,  20},
    /* P06 */{20,  20,  60, 100, 100, 100,  80, 100,  30,  20},
    /* P07 */{20,  20,  60,  60,  80, 100,  80,  80,  30,  20},
    /* P08 */{30,  30,  80,  80, 100, 100, 100,  30,  30,  20},
    /* P09 */{20,  60,  60,  80,  80, 100, 100,  80,  60,  20},
    /* P10 */{30,  80, 100,  60, 100, 100,  80, 100,  30,  20},
    /* P11 */{20,  30,  60,  80, 100, 100, 100,  80,  30,  30},
    /* P12 */{20,  20,  30,  20,  30,  30,  30,  20,  30,  20},
};
#endif /* LED_DRIVER_TM1640 */

/* hold multiplier: 0 -> 1 to avoid zero step */
static uint32_t TM_Step_Mult(bool is_hold, uint32_t hold_mult) {
    uint32_t m = is_hold ? hold_mult : 1u;
    return (m == 0u) ? 1u : m;
}

/* dir +/-1; short vs hold uses TM_*_HOLD_STEP_MULT */
static void TM_Adjust_Process(int8_t dir, bool is_hold) {
    g_TM.steady_timer = 20;
    UI_MarkDirty();
    bool is_limit = false;

    switch (g_TM.disp_index) {
        case DISP_SPEED: {
            uint32_t mult = TM_Step_Mult(is_hold, (uint32_t)TM_SPEED_HOLD_STEP_MULT);
            uint32_t delta = (uint32_t)TM_SPEED_STEP * mult;
            if (dir > 0) {
                if (g_TM.speed >= TM_SPEED_MAX) is_limit = true;
                else {
                    uint32_t ns = (uint32_t)g_TM.speed + delta;
                    if (ns > TM_SPEED_MAX) { g_TM.speed = TM_SPEED_MAX; is_limit = true; }
                    else g_TM.speed = (uint16_t)ns;
                }
            } else {
                if (g_TM.speed <= TM_SPEED_MIN) is_limit = true;
                else {
                    int32_t ns = (int32_t)g_TM.speed - (int32_t)delta;
                    if (ns < TM_SPEED_MIN) { g_TM.speed = TM_SPEED_MIN; is_limit = true; }
                    else g_TM.speed = (uint16_t)ns;
                }
            }
            if (g_TM.state == TM_STATE_RUNNING) Send_Speed_To_Lower();
            break;
        }
        case DISP_TIME: {
            uint32_t mult = TM_Step_Mult(is_hold, (uint32_t)TM_TIME_HOLD_STEP_MULT);
            uint32_t delta = (uint32_t)TM_TIME_STEP * mult;
            if (dir > 0) {
                if (g_TM.time >= TM_TIME_MAX) g_TM.time = TM_TIME_MIN;
                else {
                    uint64_t ns = (uint64_t)g_TM.time + (uint64_t)delta;
                    if (ns > (uint64_t)TM_TIME_MAX) { g_TM.time = TM_TIME_MAX; is_limit = true; }
                    else g_TM.time = (uint32_t)ns;
                }
            } else {
                if (g_TM.time <= TM_TIME_MIN) g_TM.time = TM_TIME_MAX;
                else {
                    if (g_TM.time - TM_TIME_MIN < delta) { g_TM.time = TM_TIME_MIN; is_limit = true; }
                    else g_TM.time -= delta;
                }
            }
            break;
        }
        case DISP_DIST: {
            uint32_t mult = TM_Step_Mult(is_hold, (uint32_t)TM_DIST_HOLD_STEP_MULT);
            float delta = TM_DIST_STEP * (float)mult;
            if (dir > 0) {
                if (g_TM.dist >= TM_DIST_MAX) g_TM.dist = TM_DIST_MIN;
                else {
                    float nd = g_TM.dist + delta;
                    if (nd > TM_DIST_MAX) { g_TM.dist = TM_DIST_MAX; is_limit = true; }
                    else g_TM.dist = nd;
                }
            } else {
                if (g_TM.dist <= TM_DIST_MIN) g_TM.dist = TM_DIST_MAX;
                else {
                    float nd = g_TM.dist - delta;
                    if (nd < TM_DIST_MIN) { g_TM.dist = TM_DIST_MIN; is_limit = true; }
                    else g_TM.dist = nd;
                }
            }
            break;
        }
        case DISP_CAL: {
            uint32_t mult = TM_Step_Mult(is_hold, (uint32_t)TM_CAL_HOLD_STEP_MULT);
            float delta = TM_CAL_STEP * (float)mult;
            if (dir > 0) {
                if (g_TM.cal >= TM_CAL_MAX) g_TM.cal = TM_CAL_MIN;
                else {
                    float nc = g_TM.cal + delta;
                    if (nc > TM_CAL_MAX) { g_TM.cal = TM_CAL_MAX; is_limit = true; }
                    else g_TM.cal = nc;
                }
            } else {
                if (g_TM.cal <= TM_CAL_MIN) g_TM.cal = TM_CAL_MAX;
                else {
                    float nc = g_TM.cal - delta;
                    if (nc < TM_CAL_MIN) { g_TM.cal = TM_CAL_MIN; is_limit = true; }
                    else g_TM.cal = nc;
                }
            }
            break;
        }
        default: break;
    }
    if (is_limit) Beep_Play(BEEP_LIMIT);
}

/* true=handled, false=ignored */
bool Treadmill_On_Event(uint8_t key_id, uint8_t evt) {
    if (evt == K_EVT_RELEASE) return false;
    if ((key_id == K_ID_MODE || key_id == K_ID_ONOFF) && evt == K_EVT_HOLD) return false;

    if (g_TM.state == TM_STATE_BOOT) {
        if (key_id == K_ID_ONOFF || key_id == K_ID_MODE) {
            g_TM.state = TM_STATE_IDLE;
            g_TM.timer_100ms = 0;
            Treadmill_Reset_Data();
            UI_MarkDirty();
            return true;
        }
        return false;
    }

    switch (g_TM.state) {
        case TM_STATE_IDLE:
            if (key_id == K_ID_UP || key_id == K_ID_DN) return false;
            if (key_id == K_ID_ONOFF) {
                Treadmill_Reset_Data();
                g_TM.state = TM_STATE_COUNTDOWN;
                g_TM.timer_100ms         = 30;
                s_cd_run_resend_100ms    = 0;
            } else if (key_id == K_ID_MODE) {
                g_TM.state = TM_STATE_SETTING;
                Treadmill_Reset_Data();
                g_TM.disp_index  = DISP_TIME;
                g_TM.target_mode = TARGET_TIME;
                g_TM.time        = TM_TIME_SET;
            }
            break;

        case TM_STATE_SETTING:
            if (key_id == K_ID_MODE) {
                /* 切换设置项：离开当前项时清零，确保只有一个目标有效 */
                if (g_TM.disp_index == DISP_TIME) {
                    g_TM.time        = 0;               /* 清零时间目标 */
                    g_TM.disp_index  = DISP_DIST;
                    g_TM.target_mode = TARGET_DIST;
                    g_TM.dist        = TM_DIST_SET;     /* 路程预设默认值 */
                } else if (g_TM.disp_index == DISP_DIST) {
                    g_TM.dist        = 0.0f;            /* 清零路程目标 */
                    g_TM.disp_index  = DISP_CAL;
                    g_TM.target_mode = TARGET_CAL;
                    g_TM.cal         = TM_CAL_SET;      /* 卡路里预设默认值 */
                } else if (g_TM.disp_index == DISP_CAL) {
                    g_TM.cal         = 0.0f;            /* 清零卡路里目标 */
                    g_TM.disp_index  = DISP_PROGRAM;
                    g_TM.target_mode = TARGET_PROGRAM;
                    g_TM.prog_index  = 0;               /* 从 P01 开始 */
                } else if (g_TM.disp_index == DISP_PROGRAM) {
                    /* P01..P12 循环，P12 之后回到待机 */
                    if (g_TM.prog_index < (uint8_t)(TM_PROG_COUNT - 1u)) {
                        g_TM.prog_index++;
                    } else {
                        g_TM.state = TM_STATE_IDLE;
                        Treadmill_Reset_Data();
                    }
                } else {
                    g_TM.state = TM_STATE_IDLE;
                    Treadmill_Reset_Data();
                }
            } else if (key_id == K_ID_UP || key_id == K_ID_DN) {
                /* DISP_PROGRAM 无需手动调整（程序速度固定） */
                if (g_TM.disp_index != DISP_PROGRAM)
                    TM_Adjust_Process(key_id == K_ID_UP ? 1 : -1, (evt == K_EVT_HOLD));
            } else if (key_id == K_ID_ONOFF) {
                if (g_TM.disp_index == DISP_PROGRAM) {
                    /* 启动 P 程序：初始化分段状态和第一段速度 */
                    g_TM.prog_seg        = 0;
                    g_TM.seg_elapsed_sec = 0;
                    g_TM.time            = 0;   /* 程序从 0 开始正计时 */
                    g_TM.speed = c_prog_speed[g_TM.prog_index][0];
                }
                g_TM.state = TM_STATE_COUNTDOWN;
                g_TM.timer_100ms      = 30;
                s_cd_run_resend_100ms = 0;
            }
            break;

        case TM_STATE_COUNTDOWN:
            if (key_id == K_ID_ONOFF) {
                /* 321 倒计时期间再按启停：通知下控停，并立即回待机（不等 run_status=10） */
                AeroLink_Send(FC_CONTROL, FC_CTRL_SFC_STOP, (void*)0);
                Treadmill_Reset_Data();
                g_TM.state = TM_STATE_IDLE;
            }
            break;

        case TM_STATE_RUNNING:
            if (key_id == K_ID_MODE) return false;
            if (key_id == K_ID_ONOFF) {
                s_stop_initial_spd = g_TM.speed;
                s_stop_ramp_err    = 0;
                s_stop_ramp_dur    = prv_stop_ramp_duration_ticks(s_stop_initial_spd);
                g_TM.time = 0; /* 停机界面时间固定 0，避免内部秒数仍递增被别处使用 */
                g_TM.state = TM_STATE_STOPPING;
                g_TM.pending_lower_standby    = false;
                g_TM.lower_standby_wait_100ms = 0;
                g_TM.timer_100ms          = s_stop_ramp_dur;
                s_stop_cmd_resend_100ms   = 0;
                AeroLink_Send(FC_CONTROL, FC_CTRL_SFC_STOP, (void*)0);
            } else if (key_id == K_ID_UP || key_id == K_ID_DN) {
                g_TM.disp_index = DISP_SPEED; g_TM.cycle_timer = 0;
                TM_Adjust_Process(key_id == K_ID_UP ? 1 : -1, (evt == K_EVT_HOLD));
            }
            break;

        case TM_STATE_STOPPING:
            return false;

        default: break;
    }
    UI_MarkDirty();
    return true;
}


/* TM1640: 逻辑格按板位1..13连续映射(ui_display.h)。速度0..2；时间3..6；路程/卡7..9；位12..13=10..12 */
#if (LED_DRIVER_TYPE == LED_DRIVER_TM1640)

#define TM1640_ZONE_SPEED   0
#define TM1640_ZONE_TIME    3
#define TM1640_ZONE_SHARED  7

#define TM1640_IND_GRID_SPEED  10   /* 位8 */
#define TM1640_IND_GRID_FUNC   11   /* 位5：功能灯+时间区冒号笔段 */
#define TM1640_IND_SEG_SPEED   5
#define TM1640_IND_SEG_TIME    6
#define TM1640_IND_SEG_DIS     3
#define TM1640_IND_SEG_CAL     2

#define TM1640_IndSpeed(m)  UI_SetBitMode(TM1640_IND_GRID_SPEED, TM1640_IND_SEG_SPEED, (m))
#define TM1640_IndTime(m)   UI_SetBitMode(TM1640_IND_GRID_FUNC, TM1640_IND_SEG_TIME, (m))
#define TM1640_IndDis(m)    UI_SetBitMode(TM1640_IND_GRID_FUNC, TM1640_IND_SEG_DIS, (m))
#define TM1640_IndCal(m)    UI_SetBitMode(TM1640_IND_GRID_FUNC, TM1640_IND_SEG_CAL, (m))

/* 在共享区（逻辑格 7-9）显示 "P xx"（P01-P12） */
static void prv_show_program_id(uint8_t prog_idx)
{
    uint8_t num = (uint8_t)(prog_idx + 1u);   /* 1..12 */
    UI_SetRaw(TM1640_ZONE_SHARED,      SEG_RAW(SEG_P));
    UI_SetNumber(TM1640_ZONE_SHARED + 1u, num, 2u, 0u, ZERO_SHOW);
}

/* ----------------------------------------------------------------
 * 跑马灯（12 个 LED）
 * UI_SetBitMode 的 bit 为「笔段位」a..g=0..6、DP=7（见 plat_segment.h），仅 0..7 有效。
 * 逻辑格 11（GR12）上 bit2=卡路里灯 bit3=路程灯 bit6=时间灯，跑马灯用 0,1,4,5（共 4 颗，与格10五颗+格12三颗=12）。
 * 逻辑格 10（GR11）上 bit5=速度灯，跑马灯用 0..4（你板 5 颗）。
 * 逻辑格 12（GR13）三灯：原理图 SG1→SEG7→笔段 F(5)；SG6→SEG4→E(4)；
 * SG7→SEG5→笔段 G(6)。勿用 bit7(DP)：DP 经 UI_SEG_DP_HW 走 SEG1，点不亮 SG7。
 * 序号 0 最先点亮，11 最后点亮。
 * ---------------------------------------------------------------- */
#define TM_MARQUEE_COUNT    12u
#define TM_MARQUEE_IDLE_STEP  2u   /* 空闲呼吸：每 2×100ms 步进一格 */
#define TM_MARQUEE_RUN_STEP  50u   /* 运行模式：每 50×100ms=5s 步进一格 */

typedef struct { uint8_t grid; uint8_t bit; } MarqueePos_t;

static const MarqueePos_t c_marquee[TM_MARQUEE_COUNT] = {
    /* GR11 逻辑格10：右→左 bit4..0（跳过 bit5=速度灯） */
    {10u, 4u}, {10u, 3u}, {10u, 2u}, {10u, 1u}, {10u, 0u},
    /* GR13 逻辑格12：LED36 SG1→F(5)；LED58 SG6→E(4)；LED61 SG7→G(6)，非 DP(7) */
    {12u, 5u}, {12u, 4u}, {12u, 6u},
    /* GR12 逻辑格11：A/B/E/F（4 颗）；勿用 bit7(DP) 以免与 SEG1 走线混淆 */
    {11u, 4u}, {11u, 1u}, {11u, 0u}, {11u, 5u},
};

/* 将前 n 个跑马灯点亮，其余全灭 */
static void prv_marquee_set(uint8_t n)
{
    uint8_t i;
    for (i = 0u; i < TM_MARQUEE_COUNT; i++) {
        UI_SetBitMode(c_marquee[i].grid, c_marquee[i].bit,
                      (i < n) ? DISP_ON : DISP_OFF);
    }
}

/* 每次全屏绘制后同步跑马灯（指示灯已写好，避免 GR12 与功能灯竞争丢状态） */
static void prv_marquee_sync_after_leds(void)
{
    switch (g_TM.state) {
        case TM_STATE_IDLE:
        case TM_STATE_RUNNING:
        case TM_STATE_COUNTDOWN:
            prv_marquee_set(s_mq_on);
            break;
        case TM_STATE_STOPPING:
            prv_marquee_set(s_mq_on);
            break;
        case TM_STATE_SETTING:
        case TM_STATE_ERROR:
            prv_marquee_set(0u);
            break;
        default:
            break;
    }
}

/* 每 100ms 调用一次，按状态更新跑马灯 */
static void prv_marquee_update(void)
{
    switch (g_TM.state) {

        case TM_STATE_IDLE:
        case TM_STATE_COUNTDOWN:
            /* 呼吸效果：0 → 12 → 0 循环（321 与空闲一致，避免整屏跑马灯熄灭） */
            if (++s_mq_tick < TM_MARQUEE_IDLE_STEP) break;
            s_mq_tick = 0u;
            if (s_mq_dir > 0) {
                if (s_mq_on < TM_MARQUEE_COUNT) s_mq_on++;
                if (s_mq_on >= TM_MARQUEE_COUNT) s_mq_dir = -1;
            } else {
                if (s_mq_on > 0u) s_mq_on--;
                if (s_mq_on == 0u) s_mq_dir = 1;
            }
            prv_marquee_set(s_mq_on);
            break;

        case TM_STATE_RUNNING:
            /* 每 5s 逐一点亮，12 个全亮（满 60s）后归零重新开始 */
            if (++s_mq_tick < TM_MARQUEE_RUN_STEP) break;
            s_mq_tick = 0u;
            if (s_mq_on < TM_MARQUEE_COUNT) {
                s_mq_on++;
            } else {
                s_mq_on = 0u;
            }
            prv_marquee_set(s_mq_on);
            break;

        case TM_STATE_SETTING:
            /* 设置界面：跑马灯熄灭 */
            s_mq_tick = 0u;
            if (s_mq_on != 0u) {
                s_mq_on = 0u;
                prv_marquee_set(0u);
            }
            break;

        case TM_STATE_STOPPING:
            if (g_TM.timer_100ms > 0u) {
                /* 停机减速期间跑马灯与运行态相同步进 */
                if (++s_mq_tick < TM_MARQUEE_RUN_STEP) break;
                s_mq_tick = 0u;
                if (s_mq_on < TM_MARQUEE_COUNT) {
                    s_mq_on++;
                } else {
                    s_mq_on = 0u;
                }
                prv_marquee_set(s_mq_on);
            }
            break;

        default:
            break;
    }
}

static void prv_tm1640_function_leds(void)
{
    switch (g_TM.state) {
        case TM_STATE_IDLE:
        case TM_STATE_RUNNING:
            TM1640_IndSpeed(DISP_ON);
            TM1640_IndTime(DISP_ON);
            if (s_tm1640_shared_cal) {
                TM1640_IndDis(DISP_OFF);
                TM1640_IndCal(DISP_ON);
            } else {
                TM1640_IndCal(DISP_OFF);
                TM1640_IndDis(DISP_ON);
            }
            break;

        case TM_STATE_STOPPING:
            if (g_TM.timer_100ms > 0u) {
                TM1640_IndSpeed(DISP_ON);
                TM1640_IndTime(DISP_OFF);
                if (s_tm1640_shared_cal) {
                    TM1640_IndDis(DISP_OFF);
                    TM1640_IndCal(DISP_ON);
                } else {
                    TM1640_IndCal(DISP_OFF);
                    TM1640_IndDis(DISP_ON);
                }
            }
            break;

        case TM_STATE_SETTING:
            /* 设置模式：指示灯跟随当前设置项 */
            TM1640_IndSpeed(DISP_ON);
            TM1640_IndTime(DISP_ON);
            if (g_TM.disp_index == DISP_CAL) {
                TM1640_IndDis(DISP_OFF);
                TM1640_IndCal(DISP_ON);
            } else if (g_TM.disp_index == DISP_PROGRAM) {
                /* P 模式选择：共享区显示程序号，两个灯均熄灭 */
                TM1640_IndDis(DISP_OFF);
                TM1640_IndCal(DISP_OFF);
            } else {
                /* DIST / TIME / SPEED 设置显示路程灯 */
                TM1640_IndCal(DISP_OFF);
                TM1640_IndDis(DISP_ON);
            }
            break;

        case TM_STATE_COUNTDOWN:
            /* 与空闲/运行一致：时间、路程/卡路里灯保持点亮 */
            TM1640_IndSpeed(DISP_ON);
            TM1640_IndTime(DISP_ON);
            if (s_tm1640_shared_cal) {
                TM1640_IndDis(DISP_OFF);
                TM1640_IndCal(DISP_ON);
            } else {
                TM1640_IndCal(DISP_OFF);
                TM1640_IndDis(DISP_ON);
            }
            break;
        case TM_STATE_ERROR:
            TM1640_IndSpeed(DISP_OFF);
            TM1640_IndTime(DISP_OFF);
            TM1640_IndDis(DISP_OFF);
            TM1640_IndCal(DISP_OFF);
            break;
        default:
            break;
    }
}

static void TM_FullDisplay_Render(void) {
    /* 状态切换时清屏（防止跨状态残影）；
     * 同一状态内 disp_index 切换无需清屏，每帧均完整重绘各区 */
    static TM_State_t s_last_state = TM_STATE_BOOT;
    if (g_TM.state != s_last_state) {
        UI_ClearAll();
        s_last_state = g_TM.state;
    }

    UI_SetBlinkTime(1000);

    /* 设置模式下当前选中区域闪烁 */
    bool is_blink = (g_TM.state == TM_STATE_SETTING && g_TM.steady_timer == 0);
    for (uint8_t i = 0; i < 3u; i++) {
        UI_SetGridBlinkMask(TM1640_ZONE_SPEED  + i,
            is_blink && (g_TM.disp_index == DISP_SPEED));
        UI_SetGridBlinkMask(TM1640_ZONE_SHARED + i,
            is_blink && (g_TM.disp_index == DISP_CAL    ||
                         g_TM.disp_index == DISP_DIST   ||
                         g_TM.disp_index == DISP_PROGRAM));
    }
    for (uint8_t i = 0; i < 4u; i++) {
        uint8_t gtime = (uint8_t)(TM1640_ZONE_TIME + i);
        _Bool tblink = is_blink && (g_TM.disp_index == DISP_TIME);
        /* 冒号格：整格 0xFF 会把 DP 与数字一起灭；用 0x7F 只闪 a~g，DP 由末尾 SetBitMode 单独闪 */
        if (gtime == GRID_COLON && tblink)
            UI_SetGridBlinkMaskValue(gtime, 0x7Fu);
        else
            UI_SetGridBlinkMask(gtime, tblink);
    }

    switch (g_TM.state) {

        case TM_STATE_COUNTDOWN: {
            uint8_t cd = (uint8_t)((g_TM.timer_100ms + 9u) / 10u);
            if (cd < 1u) cd = 1u;
            /* 321 不重刷全黑：时间区、共享区照常显示，仅速度区中间为 3/2/1 */
            UI_SetNumber(TM1640_ZONE_TIME, TM_Time_MMSS_For_Display(), 4u, 3u, ZERO_SHOW);
            if (g_TM.disp_index == DISP_PROGRAM) {
                prv_show_program_id(g_TM.prog_index);
            } else if (s_tm1640_shared_cal) {
                UI_SetNumber(TM1640_ZONE_SHARED,
                    (uint16_t)(g_TM.cal / 1000.0f), 3u, 0u, ZERO_SHOW);
            } else {
                UI_SetNumber(TM1640_ZONE_SHARED,
                    TM_Dist_Tenths_For_Display(), 3u, 2u, ZERO_SHOW);
            }
            UI_SetRaw(TM1640_ZONE_SPEED, 0);
            UI_SetNumber(TM1640_ZONE_SPEED + 1u, cd, 1u, 0u, ZERO_HIDE);
            UI_SetRaw(TM1640_ZONE_SPEED + 2u, 0);
            break;
        }

        case TM_STATE_STOPPING:
            if (g_TM.timer_100ms > 0u) {
                /* 速度区：线性减速；时间区固定 00:00（不显示停机剩余秒） */
                UI_SetNumber(TM1640_ZONE_SPEED, g_TM.speed, 3u, 2u, ZERO_SHOW);
                UI_SetNumber(TM1640_ZONE_TIME, 0u, 4u, 3u, ZERO_SHOW);
                if (s_tm1640_shared_cal)
                    UI_SetNumber(TM1640_ZONE_SHARED,
                        (uint16_t)(g_TM.cal / 1000.0f), 3u, 0u, ZERO_SHOW);
                else
                    UI_SetNumber(TM1640_ZONE_SHARED,
                        TM_Dist_Tenths_For_Display(), 3u, 2u, ZERO_SHOW);
            }
            break;

        case TM_STATE_IDLE:
        case TM_STATE_SETTING:
        case TM_STATE_RUNNING: {
            /* 速度区 */
            /* 速度 0.1km/h：三位显示 xx.x；dot_pos=从右数第几位加 DP（非 GRID 号）。
             * 中间位=逻辑格1→显存 GRID10，DP→SEG1 由 ui_display.h 的 UI_SEG_DP_HW 打包 */
            UI_SetNumber(TM1640_ZONE_SPEED, g_TM.speed, 3u, 2u, ZERO_SHOW);

            /* 时间区：
             * - TIME 设置 / 运行 / 空闲：正常显示 g_TM.time
             * - 其他设置项（DIST / CAL / PROGRAM）：显示 00:00 */
            if (g_TM.state == TM_STATE_SETTING && g_TM.disp_index != DISP_TIME) {
                UI_SetNumber(TM1640_ZONE_TIME, 0u, 4u, 3u, ZERO_SHOW);
            } else {
                UI_SetNumber(TM1640_ZONE_TIME, TM_Time_MMSS_For_Display(), 4u, 3u, ZERO_SHOW);
            }

            /* 共享区（路程/卡路里/Program）*/
            if (g_TM.disp_index == DISP_PROGRAM) {
                /* P 模式设置界面：显示 P01-P12 */
                prv_show_program_id(g_TM.prog_index);
            } else if (g_TM.state == TM_STATE_SETTING &&
                       g_TM.disp_index == DISP_CAL) {
                UI_SetNumber(TM1640_ZONE_SHARED,
                    (uint16_t)(g_TM.cal / 1000.0f), 3u, 0u, ZERO_SHOW);
            } else if (g_TM.state == TM_STATE_SETTING &&
                       g_TM.disp_index == DISP_DIST) {
                UI_SetNumber(TM1640_ZONE_SHARED,
                    TM_Dist_Tenths_For_Display(), 3u, 2u, ZERO_SHOW);
            } else {
                /* 运行/空闲：5s 轮换路程与卡路里 */
                if (s_tm1640_shared_cal)
                    UI_SetNumber(TM1640_ZONE_SHARED,
                        (uint16_t)(g_TM.cal / 1000.0f), 3u, 0u, ZERO_SHOW);
                else
                    UI_SetNumber(TM1640_ZONE_SHARED,
                        TM_Dist_Tenths_For_Display(), 3u, 2u, ZERO_SHOW);
            }
            break;
        }

        case TM_STATE_ERROR:
            UI_ClearAll();
            UI_SetRaw(TM1640_ZONE_SPEED, SEG_RAW(SEG_E));
            UI_SetNumber(TM1640_ZONE_SPEED + 1u, g_TM.error_code, 2u, 0u, ZERO_SHOW);
            break;

        default: break;
    }

    /* 时间冒号：显示时间区时持续闪烁（TM1640 上 H/L 均映射为 _SEG_DP，写 H 即可） */
    if (g_TM.state == TM_STATE_IDLE || g_TM.state == TM_STATE_SETTING ||
        g_TM.state == TM_STATE_RUNNING || g_TM.state == TM_STATE_COUNTDOWN) {
        UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK);
    } else if (g_TM.state == TM_STATE_STOPPING && g_TM.timer_100ms > 0u) {
        /* 停机时时间固定 00:00：冒号常亮不闪，避免沿用运行态闪烁 */
        UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_ON);
    }

    prv_tm1640_function_leds();
    prv_marquee_sync_after_leds();
}

#endif /* LED_DRIVER_TM1640 */


static void TM_UI_Dispatcher(void) {
    if (g_TM.state == TM_STATE_BOOT) {
        if (g_TM.timer_100ms == 0) Beep_Play(BEEP_CLICK);
        if (++g_TM.timer_100ms < 10) {
            for (uint8_t i = 0; i < UI_GRID_MAX; i++) UI_SetRaw(i, 0xFF);
#ifdef BOOT_SHOW_VERSION
        } else if (g_TM.timer_100ms < 25) {
            if (g_TM.timer_100ms == 10) UI_ClearAll();
            UI_SetRaw(0, SEG_RAW(SEG_U)); UI_SetNumber(1, FW_VER_U, 2, 2, ZERO_SHOW);
        } else if (g_TM.timer_100ms < 40) {
            if (g_TM.timer_100ms == 25) UI_ClearAll();
            UI_SetRaw(0, SEG_RAW(SEG_C)); UI_SetNumber(1, FW_VER_C, 2, 2, ZERO_SHOW);
        } else {
            g_TM.state = TM_STATE_IDLE; g_TM.timer_100ms = 0;
        }
#else
        } else {
            g_TM.state = TM_STATE_IDLE; g_TM.timer_100ms = 0;
        }
#endif
        return;
    }

#if (LED_DRIVER_TYPE == LED_DRIVER_TM1640)
    TM_FullDisplay_Render();
    return;
#endif

    static TM_State_t     s_last_state = TM_STATE_BOOT;
    static TM_DispIndex_t s_last_disp  = DISP_SPEED;
    if (g_TM.state != s_last_state || g_TM.disp_index != s_last_disp) {
        UI_ClearAll(); s_last_state = g_TM.state; s_last_disp = g_TM.disp_index;
    }

    for (uint8_t i = 0; i < 6; i++) UI_SetBitMode(GRID_IND, i, DISP_OFF);

    bool is_blink = (g_TM.state == TM_STATE_SETTING && g_TM.steady_timer == 0);
    UI_SetBlinkTime(1000);
    for (uint8_t i = 0; i < 4; i++) UI_SetGridBlinkMask(i, is_blink);

    switch (g_TM.state) {
        case TM_STATE_IDLE:
            UI_SetNumber(0, 0, 4, 0, ZERO_SHOW); /* 0:00 */
            UI_SetBitMode(GRID_IND,   LED_TIME,    DISP_ON);
            UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK);
            UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_BLINK);
            break;

        case TM_STATE_COUNTDOWN: {
            uint8_t cd = (g_TM.timer_100ms + 9) / 10;
            if (cd < 1) cd = 1;
            UI_SetNumber(0, TM_Time_MMSS_For_Display(), 4, 3, ZERO_SHOW);
            UI_SetNumber(2, cd, 1, 0, ZERO_HIDE);
            UI_SetBitMode(GRID_IND, LED_TIME, DISP_ON);
            UI_SetBitMode(GRID_IND, LED_SPEED, DISP_ON);
            UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK);
            UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_BLINK);
            break;
        }

        case TM_STATE_STOPPING: {
            if (g_TM.timer_100ms > 0) {
                UI_SetNumber(0, 0, 4, 0, ZERO_SHOW); /* 时间固定 0:00 */
                uint16_t spd = g_TM.speed;
                if (spd < 10) UI_SetNumber(1, spd, 2, 2, ZERO_SHOW);
                else          UI_SetNumber(0, spd, 3, 2, ZERO_HIDE);
                UI_SetBitMode(GRID_IND, LED_SPEED, DISP_ON);
                UI_SetBitMode(GRID_IND, LED_TIME, DISP_OFF);
            } else {
                uint16_t spd = g_TM.speed;
                if (spd < 10) UI_SetNumber(1, spd, 2, 2, ZERO_SHOW);
                else          UI_SetNumber(0, spd, 3, 2, ZERO_HIDE);
                UI_SetBitMode(GRID_IND, LED_SPEED, DISP_ON);
            }
            break;
        }

        case TM_STATE_SETTING:
        case TM_STATE_RUNNING:
            if (g_TM.disp_index == DISP_SPEED) {
                uint16_t spd = g_TM.speed;
                if (spd < 10) UI_SetNumber(1, spd, 2, 2, ZERO_SHOW);
                else          UI_SetNumber(0, spd, 3, 2, ZERO_HIDE);
                UI_SetBitMode(GRID_IND, LED_SPEED, DISP_ON);
            } else if (g_TM.disp_index == DISP_TIME) {
                uint16_t m = TM_Time_Minutes_For_Display();
                UI_SetNumber(0, m, 4, 0, ZERO_SHOW); /* 0:mm */
                UI_SetBitMode(GRID_IND,   LED_TIME,    DISP_ON);
                UI_SetBitMode(GRID_COLON, SEG_COLON_H, DISP_BLINK);
                UI_SetBitMode(GRID_COLON, SEG_COLON_L, DISP_BLINK);
            } else if (g_TM.disp_index == DISP_DIST) {
                UI_SetNumber(0, TM_Dist_Tenths_For_Display(), 3, 2, ZERO_SHOW); /* km 01.0..99.0 */
                UI_SetBitMode(GRID_IND, LED_DIS, DISP_ON);
                UI_SetBitMode(1, 7, is_blink ? DISP_BLINK : DISP_ON);
            } else if (g_TM.disp_index == DISP_CAL) {
                UI_SetNumber(0, (uint32_t)(g_TM.cal / 1000.0f), 4, 0, ZERO_HIDE);
                UI_SetBitMode(GRID_IND, LED_CAL, DISP_ON);
            }
            break;

        case TM_STATE_ERROR:
            UI_SetRaw(0, SEG_RAW(SEG_E));
            UI_SetNumber(1, g_TM.error_code, 2, 0, ZERO_SHOW);
            UI_SetRaw(3, 0);
            break;

        default: break;
    }
}

/* 100ms: state machine + dist/time/cal */
void Treadmill_Manager_100ms(void) {
    static float      s_accum_dist       = 0.0f;
    static TM_State_t s_mgr_prev_state   = TM_STATE_BOOT;
    static uint8_t    s_spd_resend_100ms = 0u;

    if (s_mgr_prev_state != TM_STATE_RUNNING && g_TM.state == TM_STATE_RUNNING) {
        s_spd_resend_100ms   = 0u;
        s_lower_spd_rx_tenth = g_TM.speed;
    }
    s_mgr_prev_state = g_TM.state;

    if (g_TM.steady_timer > 0 && --g_TM.steady_timer == 0) UI_MarkDirty();

    /* 等下控待机：超时强制回待机（与 AeroLink run_status=10 二选一）。
     * 若注释掉此段，取消倒计时/停机后仅依赖串口 10：无应答时会冻结界面、按键失效。 */
    if (g_TM.pending_lower_standby) {
        if (++g_TM.lower_standby_wait_100ms >= TM_LOWER_STANDBY_WAIT_MAX) {
            g_TM.pending_lower_standby    = false;
            g_TM.lower_standby_wait_100ms = 0;
            g_TM.state = TM_STATE_IDLE;
            Treadmill_Reset_Data();
            UI_MarkDirty();
        }
    }

//    if (g_TM.state == TM_STATE_RUNNING || g_TM.state == TM_STATE_STOPPING) {
//        if (++g_comm_timeout_cnt >= COMM_TIMEOUT_COUNT) {
//            g_comm_timeout_cnt = 0;
//            g_TM.state      = TM_STATE_ERROR;
//            g_TM.error_code = 16;
//            Beep_Play(BEEP_ALARM);
//        }
//    } else {
//        g_comm_timeout_cnt = 0;
//    }

    if (g_TM.state == TM_STATE_COUNTDOWN) {
        if (!g_TM.pending_lower_standby) {
            if (g_TM.timer_100ms > 0) {
                g_TM.timer_100ms--;
                if (g_TM.timer_100ms == 20 || g_TM.timer_100ms == 10) Beep_Play(BEEP_CLICK);
                /* 显示「1」时先发 RUN_START；其后若下控未报运行(9)则周期重发 */
                if (g_TM.timer_100ms == 10) {
                    AeroLink_Send(FC_CONTROL, FC_CTRL_SFC_RUN_START, (void*)0);
                    Send_Speed_To_Lower();
                    s_cd_run_resend_100ms = 0;
                } else if (g_TM.timer_100ms < 10) {
                    if (s_lower_last_run_status != 9u) {
                        if (++s_cd_run_resend_100ms >= 3u) {
                            s_cd_run_resend_100ms = 0;
                            AeroLink_Send(FC_CONTROL, FC_CTRL_SFC_RUN_START, (void*)0);
                            Send_Speed_To_Lower();
                        }
                    } else {
                        s_cd_run_resend_100ms = 0;
                    }
                }
            } else {
                /* P 程序速度已在 ONOFF 处理时设定，其余模式从最低速起步 */
                if (g_TM.target_mode != TARGET_PROGRAM)
                    g_TM.speed = TM_SPEED_MIN;
                g_TM.state       = TM_STATE_RUNNING;
                g_TM.cycle_timer = 0;
#if (LED_DRIVER_TYPE == LED_DRIVER_TM1640)
                s_tm1640_swap_100ms = 0;
                /* 运行态流水从第 1 位重新跑，不接在空闲/321 呼吸灯当前格后面 */
                s_mq_on   = 0u;
                s_mq_tick = 0u;
                s_mq_dir  = 1;
                prv_marquee_set(0u);
#endif
                g_TM.disp_index  = DISP_SPEED;
                s_accum_dist     = 0.0f;
                if (g_TM.target_mode != TARGET_TIME) g_TM.time = 0;
                if (g_TM.target_mode != TARGET_DIST) g_TM.dist = 0.0f;
                if (g_TM.target_mode != TARGET_CAL)  g_TM.cal  = 0.0f;
                if (s_lower_last_run_status != 9u) {
                    AeroLink_Send(FC_CONTROL, FC_CTRL_SFC_RUN_START, (void*)0);
                }
                Send_Speed_To_Lower();
            }
        }
        /* pending_lower_standby：冻结倒计时显示，等下控 10 或超时 */
    }

    if (g_TM.state == TM_STATE_STOPPING) {
        if (g_TM.timer_100ms > 0) {
            uint16_t prev_spd = g_TM.speed;

            /* 下控已回「等待启动」(7)：电机侧已停，上显速度直接清 0 */
            if (s_lower_last_run_status == 7u) {
                if (g_TM.speed > 0u) {
                    g_TM.speed = 0u;
                    Send_Speed_To_Lower();
                }
                s_stop_ramp_err = 0;
            } else {
                uint32_t dur   = (uint32_t)s_stop_ramp_dur;
                int32_t  dur_i = (dur > 0u) ? (int32_t)dur : 1;

                /* Bresenham：每 tick 累加 init，每满 dur 减一档；dur 与进入停机时一致 */
                s_stop_ramp_err += (int32_t)s_stop_initial_spd;
                while (s_stop_ramp_err >= dur_i && g_TM.speed > 0) {
                    g_TM.speed--;
                    s_stop_ramp_err -= dur_i;
                }
                if (g_TM.speed != prev_spd)
                    Send_Speed_To_Lower();

                /* 下控仍报运行(9)时周期补发 STOP，避免偶发停不住 */
                if (s_lower_last_run_status == 9u) {
                    if (++s_stop_cmd_resend_100ms >= 5u) {
                        s_stop_cmd_resend_100ms = 0;
                        AeroLink_Send(FC_CONTROL, FC_CTRL_SFC_STOP, (void*)0);
                    }
                } else {
                    s_stop_cmd_resend_100ms = 0;
                }
            }

            g_TM.timer_100ms--;
            /* 速度先到 0 或倒计时结束：清 0 回待机（不等剩余 tick） */
            if (g_TM.speed == 0u || g_TM.timer_100ms == 0) {
                g_TM.speed = 0u;
                Send_Speed_To_Lower();
                Treadmill_Reset_Data();
                g_TM.state = TM_STATE_IDLE;
                UI_MarkDirty();
            } else {
                UI_MarkDirty();
            }
        }
    }

    if (g_TM.state == TM_STATE_RUNNING) {
        if (++s_spd_resend_100ms >= TM_SPEED_RESEND_PERIOD_100MS) {
            s_spd_resend_100ms = 0u;
            if (g_TM.speed != s_lower_spd_rx_tenth)
                Send_Speed_To_Lower();
        }
        static uint8_t sec_cnt = 0;
        if (++sec_cnt >= 10) {
            sec_cnt = 0;
            bool  trigger_stop = false;
            float dist_inc     = (float)g_TM.speed / 36.0f; /* distance delta per 1s tick, m */

            s_accum_dist += dist_inc;

            if (g_TM.target_mode == TARGET_TIME) {
                if (g_TM.time > 0) g_TM.time--;
                if (g_TM.time == 0) trigger_stop = true;
            } else {
                g_TM.time++;
                if (g_TM.time >= TM_TIME_MAX) trigger_stop = true;
            }
            if (g_TM.target_mode == TARGET_DIST) {
                g_TM.dist -= dist_inc;
                if (g_TM.dist <= 0.0f) trigger_stop = true;
            } else {
                g_TM.dist = s_accum_dist;
            }
            if (g_TM.target_mode == TARGET_CAL) {
                g_TM.cal -= dist_inc * (float)CAL_PER;
                if (g_TM.cal <= 0.0f) trigger_stop = true;
            } else {
                g_TM.cal = s_accum_dist * (float)CAL_PER;
            }

            /* P 程序：每段 3 分钟后切换速度，10 段（30 分钟）后自动停机 */
            if (g_TM.target_mode == TARGET_PROGRAM) {
                if (g_TM.time >= TM_PROG_TOTAL_SEC) {
                    trigger_stop = true;
                }
                if (!trigger_stop) {
                    if (++g_TM.seg_elapsed_sec >= (uint16_t)TM_PROG_SEG_SEC) {
                        g_TM.seg_elapsed_sec = 0;
                        g_TM.prog_seg++;
                        if (g_TM.prog_seg >= (uint8_t)TM_PROG_SEG_COUNT) {
                            trigger_stop = true;
                        } else {
                            g_TM.speed = c_prog_speed[g_TM.prog_index][g_TM.prog_seg];
                            Send_Speed_To_Lower();
                        }
                    }
                }
            }

            if (trigger_stop) {
                s_stop_initial_spd = g_TM.speed;
                s_stop_ramp_err    = 0;
                s_stop_ramp_dur    = prv_stop_ramp_duration_ticks(s_stop_initial_spd);
                g_TM.time = 0;
                g_TM.state = TM_STATE_STOPPING;
                g_TM.pending_lower_standby    = false;
                g_TM.lower_standby_wait_100ms = 0;
                g_TM.timer_100ms        = s_stop_ramp_dur;
                s_stop_cmd_resend_100ms = 0;
                Beep_Play(BEEP_CLICK);
                AeroLink_Send(FC_CONTROL, FC_CTRL_SFC_STOP, (void*)0);
            }
        }
#if (LED_DRIVER_TYPE != LED_DRIVER_TM1640)
        if (g_TM.steady_timer == 0 && ++g_TM.cycle_timer >= 50) {
            g_TM.cycle_timer = 0;
            g_TM.disp_index  = (TM_DispIndex_t)((g_TM.disp_index + 1) % 4);
        }
#endif
    }

#if (LED_DRIVER_TYPE == LED_DRIVER_TM1640)
    /* 路程/卡路里：每 50×100ms=5s 切换；不用 cycle_timer/steady_timer，避免调速后长时间不翻页 */
    {
        TM_State_t st = g_TM.state;
        if (st == TM_STATE_IDLE || st == TM_STATE_SETTING || st == TM_STATE_RUNNING ||
            st == TM_STATE_COUNTDOWN ||
            (st == TM_STATE_STOPPING && g_TM.timer_100ms > 0)) {
            /* P 设置界面固定显示程序号，不做轮换；运行/空闲状态正常5s轮换 */
            if (g_TM.disp_index == DISP_PROGRAM) {
                s_tm1640_swap_100ms = 0;
            } else {
                if (++s_tm1640_swap_100ms >= 50u) {
                    s_tm1640_swap_100ms = 0;
                    s_tm1640_shared_cal ^= 1u;
                    UI_MarkDirty();
                }
            }
        } else {
            s_tm1640_swap_100ms = 0;
        }
    }

    /* 跑马灯更新 */
    prv_marquee_update();
#endif

    TM_UI_Dispatcher();
}

/* 运行信息 Data2：协议为 Hi/Lo；值为 0/3/7/9/10（7=等待启动）。兼容单字节落在 [2] 或 [3]、以及 Lo/Hi 颠倒 */
static uint8_t prv_run_status_from_rx(const AeroRecvFrame_t *f) {
    uint16_t be = ((uint16_t)f->data[2] << 8) | f->data[3];
    if (be <= 10u) return (uint8_t)be;
    uint16_t le = ((uint16_t)f->data[3] << 8) | f->data[2];
    if (le <= 10u) return (uint8_t)le;
    if (f->data[2] <= 10u) return f->data[2];
    if (f->data[3] <= 10u) return f->data[3];
    return f->data[2];
}

/* RX: run 0x01/0x00, fault 0x01/0x01 */
void AeroLink_OnFrameReceived(AeroRecvFrame_t *f) {

    g_comm_timeout_cnt = 0;

    if (f->fc == 0x01 && f->sfc == 0x00) {
        uint8_t run_status = prv_run_status_from_rx(f);
        s_lower_last_run_status = run_status;

        if (g_TM.state == TM_STATE_BOOT || g_TM.state == TM_STATE_ERROR) return;

        /* Data1：RPM→0.1km/h；空闲/设置不写 g_TM.speed；运行/321 上显主导；STOPPING 线性减速由上控发档位，不写回 g_TM.speed */
        if (g_TM.state != TM_STATE_SETTING && g_TM.state != TM_STATE_IDLE) {
            uint16_t rpm = ((uint16_t)f->data[0] << 8) | f->data[1];
            uint32_t spd = ((uint32_t)rpm * (uint32_t)TM_LOWER_RPM_TENTH_NUM +
                            (uint32_t)TM_LOWER_RPM_TENTH_DEN / 2u) /
                           (uint32_t)TM_LOWER_RPM_TENTH_DEN;
            if (spd > (uint32_t)TM_SPEED_MAX) spd = (uint32_t)TM_SPEED_MAX;
            s_lower_spd_rx_tenth = (uint16_t)spd;
        }

        switch (run_status) {
            case 7:
                /* 下控「等待启动」：斜坡停机时勿据此清屏，否则易在 1.0→0.9 间误回待机 */
                break;
            case 9:
                /* 倒计时未结束时不跟下控强行切 RUNNING，否则本机尚未发 RUN_START，状态与协议不一致 */
                if (g_TM.state != TM_STATE_RUNNING && g_TM.state != TM_STATE_STOPPING &&
                    g_TM.state != TM_STATE_COUNTDOWN) {
                    g_TM.state = TM_STATE_RUNNING;
                }
                break;
            case 10:
                /* 下控已待机：仅在有「等下控应答」标记时回待机（勿在 RUNNING 时误收 10 打断启动） */
                if (g_TM.pending_lower_standby) {
                    g_TM.pending_lower_standby    = false;
                    g_TM.lower_standby_wait_100ms = 0;
                    g_TM.state = TM_STATE_IDLE;
                    Treadmill_Reset_Data();
                    UI_ClearAll();
                    UI_MarkDirty();
                }
                break;
            case 3:
                g_TM.state = TM_STATE_ERROR;
                break;
            default: break;
        }
    }
    else if (f->fc == 0x01 && f->sfc == 0x01) {
        uint16_t err_lv1 = ((uint16_t)f->data[0] << 8) | f->data[1];
        uint8_t  err_lv2 = f->data[2];

        if (err_lv1 != 0 || err_lv2 != 0) {
            g_TM.state = TM_STATE_ERROR;
            for (uint8_t i = 0; i < 13; i++) {
                if (err_lv1 & (1u << i)) { g_TM.error_code = i + 1; break; }
            }
            if (err_lv2 & (1 << 0)) g_TM.error_code = 14;
            if (err_lv2 & (1 << 1)) g_TM.error_code = 15;
            Beep_Play(BEEP_ALARM);
        }
    }
}
