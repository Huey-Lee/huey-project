#ifndef __PLAT_BEEP_H
#define __PLAT_BEEP_H

#include "main.h"

// 音效预设（HNR-1407A 谐振频率 4000Hz，统一用此频率，以节拍区分）
typedef enum {
    BEEP_CLICK = 0,    // 按键音：60ms 单声
    BEEP_LIMIT,        // 到限音：60ms×3 三声
    BEEP_ALARM,        // 报警音：100ms×10 急促
    BEEP_POWER_ON,     // 开机音：300ms 长鸣
} BeepMode_t;

void Beep_Init(void);
void Beep_Handler_1ms(void); 
void Beep_Play(BeepMode_t mode); // 极简调用
void Beep_Play_Custom(uint16_t freq, uint8_t vol, uint16_t on, uint16_t off, uint8_t count);

#endif
